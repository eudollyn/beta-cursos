# Guia rápido — Administração do Beta Cursos

## Como entrar

1. Abra o Beta Cursos.
2. Entre com a conta autorizada. No ambiente local ou em staging habilitado, você também pode usar **Explorar com uma conta de demonstração**.
3. Clique em **Administração**.

## Criar um curso

1. Abra **Cursos** e clique em **Novo curso**.
2. Preencha nome, resumo, descrição, categoria, nível, duração e preço.
3. Importe uma capa, se desejar.
4. Abra a aba **Conteúdo**.
5. Crie os módulos e as lições na ordem correta.
6. Clique em **Salvar rascunho** sempre que quiser continuar depois.

## Preparar uma lição

Cada lição precisa de três partes:

1. **Apostila:** envie um PDF ou escolha um PDF da biblioteca.
2. **Vídeo:** envie o arquivo, escolha um vídeo da biblioteca ou cole um link do YouTube/Vimeo.
3. **Teste:** escreva cinco questões. Cada uma deve ter quatro alternativas e uma resposta marcada como correta. A explicação é opcional, mas recomendada.

Também é possível escolher a nota mínima, o número de tentativas e se questões e alternativas serão embaralhadas.

## Publicar

1. Clique em **Verificar** para conferir as pendências.
2. Corrija todos os itens indicados.
3. Clique em **Publicar curso**.

O curso passa a aparecer no catálogo imediatamente. Para retirá-lo sem perder conteúdo ou histórico, use **Arquivar**. Somente rascunhos podem ser apagados definitivamente.

## Biblioteca de mídia

Em **Mídia**, envie apostilas, capas e vídeos uma vez e reutilize-os nas lições. Um arquivo ligado a um curso não pode ser excluído por engano; retire primeiro a referência do curso.

## Backup

Em **Backup e configurações**:

- use **Baixar backup JSON** antes de alterações grandes;
- use **Importar backup** para restaurar a lista de cursos;
- lembre que o JSON guarda os cursos e as referências dos arquivos, mas não inclui os próprios arquivos de vídeo/PDF.

## Cuidados importantes

- Não altere identificadores internos: eles preservam o progresso dos alunos.
- Guarde o backup em um local seguro.
- Revise links, apostilas e gabaritos antes de publicar.
- Arquive um curso já usado em vez de excluí-lo.
