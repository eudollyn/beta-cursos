import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { test } from 'node:test';

const adminSource = await readFile(new URL('../admin.js', import.meta.url), 'utf8');

test('uma falha de inicialização não é escondida ao trocar de seção', () => {
  const renderSource = adminSource.match(/function render\(\) \{[\s\S]*?\n  function overviewTemplate/)?.[0] || '';

  assert.match(renderSource, /if \(state\.initError\)/);
  assert.match(renderSource, /Não foi possível abrir o painel/);
  assert.ok(
    renderSource.indexOf('if (state.initError)') < renderSource.indexOf('switch (state.view)'),
    'o erro precisa ser preservado antes da renderização das seções',
  );
});

test('cada montagem limpa dados antigos e registra a falha definitiva', () => {
  assert.match(adminSource, /state\.adapter = null;/);
  assert.match(adminSource, /state\.courses = \[\];/);
  assert.match(adminSource, /state\.media = \[\];/);
  assert.match(adminSource, /state\.initError = null;/);
  assert.match(adminSource, /state\.initError = error;\s*render\(\);/);
  assert.match(adminSource, /state\.mode = 'error'/);
});

test('o armazenamento local antigo remove o desconto automático da Jornada Lidere', () => {
  assert.match(adminSource, /const LOCAL_STORE_VERSION = 2;/);
  assert.match(adminSource, /value\.id === 'jornada-lidere'/);
  assert.match(adminSource, /value\.pricing\.memberDiscount = 0;/);
  assert.match(adminSource, /value\.pricing\.discountPercent = 0;/);
});
