import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { afterEach, test } from 'node:test';
import {
  handleApplicationApi,
  resolveSession,
} from '../railway/application-api.mjs';

class D1StatementMock {
  constructor(database, sql, beforeRun) {
    this.database = database;
    this.sql = sql;
    this.beforeRun = beforeRun;
    this.values = [];
  }

  bind(...values) {
    this.values = values;
    return this;
  }

  statement() {
    return this.database.prepare(this.sql);
  }

  async run() {
    if (this.beforeRun) await this.beforeRun(this.sql, this.values);
    const result = this.statement().run(...this.values);
    return { success: true, meta: { changes: Number(result.changes || 0) } };
  }

  async all() {
    return { success: true, results: this.statement().all(...this.values) };
  }

  async first() {
    return this.statement().get(...this.values) || null;
  }

  async executeForBatch() {
    return /^\s*SELECT\b/i.test(this.sql) ? this.all() : this.run();
  }
}

class D1Mock {
  constructor() {
    this.database = new DatabaseSync(':memory:');
    this.beforeRun = null;
    this.inTransaction = false;
    this.transactionCalls = 0;
  }

  prepare(sql) {
    return new D1StatementMock(
      this.database,
      sql,
      (statementSql, values) => this.beforeRun?.(statementSql, values),
    );
  }

  async batch(statements) {
    this.database.exec('BEGIN');
    try {
      const results = [];
      for (const statement of statements) results.push(await statement.executeForBatch());
      this.database.exec('COMMIT');
      return results;
    } catch (error) {
      this.database.exec('ROLLBACK');
      throw error;
    }
  }

  async transaction(callback) {
    this.transactionCalls += 1;
    if (this.inTransaction) return callback(this);
    this.database.exec('BEGIN IMMEDIATE');
    this.inTransaction = true;
    try {
      const result = await callback(this);
      this.database.exec('COMMIT');
      return result;
    } catch (error) {
      this.database.exec('ROLLBACK');
      throw error;
    } finally {
      this.inTransaction = false;
    }
  }

  close() {
    this.database.close();
  }
}

const databases = [];
const origin = 'https://beta.test';
const baseConfig = {
  checkoutMode: 'test',
  secureCookies: true,
  scryptCost: 1_024,
  authRateLimitMax: 50,
};

afterEach(() => {
  while (databases.length) databases.pop().close();
});

function createDatabase() {
  const DB = new D1Mock();
  databases.push(DB);
  DB.database.exec(`CREATE TABLE courses (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    data_json TEXT NOT NULL
  )`);
  const course = {
    id: 'jornada-lidere',
    status: 'published',
    version: 1,
    revision: 1,
    title: 'Jornada Lidere',
    pricing: {
      fullPrice: 19.90,
      currency: 'BRL',
      paymentMethods: ['pix', 'credit_card', 'boleto'],
    },
    quizConfig: {
      passingScore: 1,
      maxAttempts: 3,
    },
    modules: [{
      id: 'modulo-1',
      order: 1,
      lessons: [
        {
          id: 'licao-1',
          order: 1,
          quiz: [{
            id: 'q1',
            correctOptionId: 'a',
            options: [{ id: 'a' }, { id: 'b' }],
          }],
        },
        {
          id: 'licao-2',
          order: 2,
          quiz: [{
            id: 'q2',
            correctOptionId: 'a',
            options: [{ id: 'a' }, { id: 'b' }],
          }],
        },
      ],
    }],
  };
  DB.database.prepare('INSERT INTO courses (id, status, data_json) VALUES (?, ?, ?)')
    .run(course.id, course.status, JSON.stringify(course));
  return DB;
}

function request(path, {
  method = 'GET',
  body,
  cookie,
  ip = '203.0.113.10',
  headers,
} = {}) {
  const requestHeaders = new Headers({
    'X-Forwarded-For': ip,
    ...(headers || {}),
  });
  if (cookie) requestHeaders.set('Cookie', cookie);
  if (body !== undefined) {
    requestHeaders.set('Content-Type', 'application/json');
    requestHeaders.set('Origin', origin);
  }
  return new Request(`${origin}${path}`, {
    method,
    headers: requestHeaders,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

function cookieFrom(response) {
  return String(response.headers.get('set-cookie') || '').split(';')[0];
}

async function payload(response) {
  return response.status === 204 ? null : response.json();
}

async function register(DB, {
  name = 'Maria da Silva',
  email = 'maria@example.com',
  password = 'uma senha longa',
  config = baseConfig,
  ip = '203.0.113.10',
} = {}) {
  const response = await handleApplicationApi(request('/api/auth/register', {
    method: 'POST',
    ip,
    body: { name, email, password },
  }), { DB, config });
  return { response, body: await payload(response), cookie: cookieFrom(response) };
}

async function checkout(DB, cookie, headers = {}) {
  const response = await handleApplicationApi(request('/api/checkouts', {
    method: 'POST',
    cookie,
    headers,
    body: {
      courseId: 'jornada-lidere',
      paymentMethod: 'pix',
      userId: 'usuario-forjado',
      role: 'owner',
      amountCents: 1,
    },
  }), { DB, config: baseConfig });
  return { response, body: await payload(response) };
}

test('catálogo público oculta conteúdo e rotas administrativas seguem para o módulo próprio', async () => {
  const DB = createDatabase();
  let response = await handleApplicationApi(request('/api/courses'), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  const catalog = await payload(response);
  const lesson = catalog.courses[0].modules[0].lessons[0];
  assert.deepEqual(lesson.quiz, []);
  assert.equal(Object.hasOwn(lesson, 'correctOptionId'), false);

  response = await handleApplicationApi(request('/api/admin/courses'), { DB, config: baseConfig });
  assert.equal(response, null);
});

test('registro exige 10 caracteres e cria sessão opaca em cookie seguro', async () => {
  const DB = createDatabase();
  let response = await handleApplicationApi(request('/api/auth/register', {
    method: 'POST',
    body: {
      name: 'Maria da Silva',
      email: 'maria@example.com',
      password: '123456789',
    },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 422);
  assert.equal((await payload(response)).error.code, 'invalid_password');

  const registration = await register(DB);
  assert.equal(registration.response.status, 201);
  assert.deepEqual(registration.body, {
    success: true,
    user: {
      id: registration.body.user.id,
      name: 'Maria da Silva',
      email: 'maria@example.com',
      memberCode: null,
      memberCodeValidated: false,
      role: 'student',
      isDemo: false,
    },
    features: {
      demoAccess: false,
      registration: true,
      paymentsMode: 'test',
    },
  });
  const setCookie = registration.response.headers.get('set-cookie');
  assert.match(setCookie, /^beta_session=[A-Za-z0-9_-]+;/);
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Lax/i);
  assert.match(setCookie, /Secure/i);

  const storedUser = DB.database.prepare(
    'SELECT password_hash FROM app_users WHERE email = ?',
  ).get('maria@example.com');
  assert.match(storedUser.password_hash, /^scrypt\$/);
  assert.doesNotMatch(storedUser.password_hash, /uma senha longa/);
  const rawToken = registration.cookie.split('=')[1];
  const storedSession = DB.database.prepare('SELECT token_hash FROM app_sessions').get();
  assert.notEqual(storedSession.token_hash, rawToken);

  const session = await resolveSession(request('/api/auth/session', {
    cookie: registration.cookie,
  }), { DB, config: baseConfig });
  assert.equal(session.email, 'maria@example.com');
});

test('login usa mensagem genérica, sessão é restaurada e logout a revoga', async () => {
  const DB = createDatabase();
  const registration = await register(DB);

  let response = await handleApplicationApi(request('/api/auth/login', {
    method: 'POST',
    ip: '203.0.113.11',
    body: { email: 'maria@example.com', password: 'senha incorreta' },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 401);
  assert.equal((await payload(response)).error.code, 'invalid_credentials');

  response = await handleApplicationApi(request('/api/auth/login', {
    method: 'POST',
    ip: '203.0.113.12',
    body: { email: 'maria@example.com', password: 'uma senha longa' },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  const loginCookie = cookieFrom(response);
  assert.equal((await payload(response)).success, true);

  response = await handleApplicationApi(request('/api/auth/session', {
    cookie: loginCookie,
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  assert.deepEqual(await payload(response), {
    authenticated: true,
    user: {
      id: registration.body.user.id,
      name: 'Maria da Silva',
      email: 'maria@example.com',
      memberCode: null,
      memberCodeValidated: false,
      role: 'student',
      isDemo: false,
    },
    features: {
      demoAccess: false,
      registration: true,
      paymentsMode: 'test',
    },
  });

  response = await handleApplicationApi(request('/api/auth/logout', {
    method: 'POST',
    cookie: loginCookie,
    body: {},
  }), { DB, config: baseConfig });
  assert.equal(response.status, 204);
  assert.match(response.headers.get('set-cookie'), /Max-Age=0/i);

  response = await handleApplicationApi(request('/api/auth/session', {
    cookie: loginCookie,
  }), { DB, config: baseConfig });
  assert.equal(response.status, 401);
  assert.deepEqual(await payload(response), {
    authenticated: false,
    features: {
      demoAccess: false,
      registration: true,
      paymentsMode: 'test',
    },
  });
});

test('limite simples de autenticação bloqueia tentativas repetidas por IP e e-mail', async () => {
  const DB = createDatabase();
  const config = {
    ...baseConfig,
    authRateLimitMax: 2,
    authRateLimitWindowMs: 60_000,
  };
  await register(DB, {
    email: 'limite@example.com',
    config,
    ip: '203.0.113.40',
  });

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const response = await handleApplicationApi(request('/api/auth/login', {
      method: 'POST',
      ip: '203.0.113.41',
      body: { email: 'limite@example.com', password: 'senha incorreta' },
    }), { DB, config });
    assert.equal(response.status, 401);
  }
  const blocked = await handleApplicationApi(request('/api/auth/login', {
    method: 'POST',
    ip: '203.0.113.41',
    body: { email: 'limite@example.com', password: 'senha incorreta' },
  }), { DB, config });
  assert.equal(blocked.status, 429);
  assert.equal((await payload(blocked)).error.code, 'auth_rate_limited');
});

test('conta demo só existe quando habilitada e o servidor determina sua função', async () => {
  const DB = createDatabase();
  let response = await handleApplicationApi(request('/api/auth/demo', {
    method: 'POST',
    body: {},
  }), { DB, config: baseConfig });
  assert.equal(response.status, 404);
  assert.equal((await payload(response)).error.code, 'demo_disabled');

  response = await handleApplicationApi(request('/api/auth/demo', {
    method: 'POST',
    ip: '203.0.113.20',
    body: { role: 'owner', userId: 'forjado' },
  }), {
    DB,
    config: {
      ...baseConfig,
      enableDemoLogin: true,
      demoRole: 'admin',
    },
  });
  assert.equal(response.status, 200);
  const body = await payload(response);
  assert.equal(body.user.role, 'admin');
  assert.notEqual(body.user.id, 'forjado');
  assert.equal(body.user.isDemo, true);

  const cookie = cookieFrom(response);
  response = await handleApplicationApi(request('/api/me/state', { cookie }), {
    DB,
    config: { ...baseConfig, enableDemoLogin: true },
  });
  assert.deepEqual((await payload(response)).enrollments, ['jornada-lidere']);
});

test('checkout de teste usa preço do servidor, é idempotente e cria matrícula real', async () => {
  const DB = createDatabase();
  const registration = await register(DB);
  let response = await handleApplicationApi(request('/api/checkouts', {
    method: 'POST',
    cookie: registration.cookie,
    body: {
      courseId: 'jornada-lidere',
      paymentMethod: 'pix',
      couponCode: 'BETA20',
    },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 422);
  assert.equal((await payload(response)).error.code, 'invalid_coupon');

  const firstCheckout = await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-maria-1',
  });
  assert.equal(firstCheckout.response.status, 200);
  assert.equal(firstCheckout.body.success, true);
  assert.equal(firstCheckout.body.status, 'approved');
  assert.equal(firstCheckout.body.testMode, true);
  assert.equal(firstCheckout.body.checkout.amountCents, 1990);
  assert.equal(firstCheckout.body.checkout.currency, 'BRL');
  assert.equal(firstCheckout.body.checkout.paymentMethod, 'pix');
  assert.equal(firstCheckout.body.enrollment.courseId, 'jornada-lidere');
  assert.equal(firstCheckout.body.enrollment.status, 'active');

  const repeated = await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-maria-1',
  });
  assert.equal(repeated.body.checkout.id, firstCheckout.body.checkout.id);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_checkouts').get().count, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_enrollments').get().count, 1);

  DB.database.prepare(
    'DELETE FROM app_progress WHERE user_id = ? AND course_id = ?',
  ).run(registration.body.user.id, 'jornada-lidere');
  DB.database.prepare(
    'DELETE FROM app_enrollments WHERE user_id = ? AND course_id = ?',
  ).run(registration.body.user.id, 'jornada-lidere');
  const repaired = await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-maria-1',
  });
  assert.equal(repaired.body.checkout.id, firstCheckout.body.checkout.id);
  assert.equal(repaired.body.enrollment.status, 'active');
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_progress').get().count, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_enrollments').get().count, 1);

  const stateResponse = await handleApplicationApi(request('/api/me/state', {
    cookie: registration.cookie,
  }), { DB, config: baseConfig });
  const state = await payload(stateResponse);
  assert.deepEqual(state.enrollments, ['jornada-lidere']);
  assert.equal(state.progress['jornada-lidere'].lessons['licao-1'].unlocked, true);
  assert.equal(state.progress['jornada-lidere'].lessons['licao-2'].unlocked, false);
});

test('checkout reverte checkout e matrícula se a criação do progresso falhar', async () => {
  const DB = createDatabase();
  const registration = await register(DB, { email: 'rollback@example.com' });
  let failurePending = true;
  DB.beforeRun = (sql) => {
    if (failurePending && /^\s*INSERT INTO app_progress\b/i.test(sql)) {
      failurePending = false;
      throw new Error('falha injetada ao criar progresso');
    }
  };

  const result = await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-rollback-1',
  });
  assert.equal(result.response.status, 500);
  assert.equal(DB.transactionCalls, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_checkouts').get().count, 0);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_enrollments').get().count, 0);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_progress').get().count, 0);
});

test('corrida de chave idempotente retorna o checkout vencedor e repara a matrícula', async () => {
  const DB = createDatabase();
  const registration = await register(DB, { email: 'corrida@example.com' });
  const originalTransaction = DB.transaction;
  DB.transaction = undefined;
  let collisionPending = true;
  DB.beforeRun = (sql, values) => {
    if (collisionPending && /^\s*INSERT INTO app_checkouts\b/i.test(sql)) {
      collisionPending = false;
      DB.database.prepare(sql).run(...values);
      const error = new Error(
        'UNIQUE constraint failed: app_checkouts.user_id, app_checkouts.idempotency_key',
      );
      error.code = 'SQLITE_CONSTRAINT_UNIQUE';
      throw error;
    }
  };

  const result = await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-corrida-1',
  });
  DB.transaction = originalTransaction;

  assert.equal(result.response.status, 200);
  assert.equal(result.body.success, true);
  assert.equal(result.body.enrollment.status, 'active');
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_checkouts').get().count, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_enrollments').get().count, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_progress').get().count, 1);
});

test('progresso ordenado ignora identidade do body e o quiz é corrigido somente no servidor', async () => {
  const DB = createDatabase();
  const registration = await register(DB);
  await checkout(DB, registration.cookie);

  let stateResponse = await handleApplicationApi(request('/api/me/state', {
    cookie: registration.cookie,
  }), { DB, config: baseConfig });
  let state = await payload(stateResponse);
  let progress = state.progress['jornada-lidere'];
  progress.userId = 'outro-usuario';
  progress.lessons['licao-2'] = {
    ...progress.lessons['licao-2'],
    unlocked: true,
    pdfRead: true,
    videoCompleted: true,
    quizAttemptsUsed: 1,
    quizScore: 1,
    quizStatus: 'passed',
    lessonCompleted: true,
  };

  let response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { userId: 'outro-usuario', progress },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  let result = await payload(response);
  assert.equal(result.progress.lessons['licao-2'].unlocked, false);
  assert.equal(result.progress.lessons['licao-2'].lessonCompleted, false);

  progress = structuredClone(result.progress);
  progress.lessons['licao-1'].pdfRead = true;
  progress.lessons['licao-1'].videoCompleted = true;
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 409);
  assert.equal((await payload(response)).error.code, 'invalid_progress_transition');

  progress.lessons['licao-1'].videoCompleted = false;
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  result = await payload(response);
  assert.equal(result.progress.lessons['licao-1'].pdfRead, true);

  progress = structuredClone(result.progress);
  progress.lessons['licao-1'].videoCompleted = true;
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  result = await payload(response);
  assert.equal(result.progress.lessons['licao-1'].quizStatus, 'available');

  progress = structuredClone(result.progress);
  Object.assign(progress.lessons['licao-1'], {
    quizAttemptsUsed: 1,
    quizScore: 1,
    quizStatus: 'passed',
    lessonCompleted: true,
  });
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 409);
  result = await payload(response);
  assert.equal(result.error.code, 'quiz_submission_required');

  response = await handleApplicationApi(request('/api/me/quiz/jornada-lidere/licao-1/attempt', {
    method: 'POST',
    cookie: registration.cookie,
    headers: { 'Idempotency-Key': 'quiz-maria-licao-1-attempt-1' },
    body: { answers: { q1: 'a' } },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);
  result = await payload(response);
  assert.equal(result.score, 1);
  assert.equal(result.passed, true);
  assert.equal(result.attemptsUsed, 1);
  assert.equal(result.results.q1.correctOptionId, 'a');
  assert.equal(result.progress.lessons['licao-1'].lessonCompleted, true);
  assert.equal(result.progress.lessons['licao-2'].unlocked, true);

  response = await handleApplicationApi(request('/api/me/quiz/jornada-lidere/licao-1/attempt', {
    method: 'POST',
    cookie: registration.cookie,
    headers: { 'Idempotency-Key': 'quiz-maria-licao-1-attempt-1' },
    body: { answers: { q1: 'b' } },
  }), { DB, config: baseConfig });
  result = await payload(response);
  assert.equal(result.idempotent, true);
  assert.equal(result.score, 1);
  assert.equal(DB.database.prepare('SELECT COUNT(*) AS count FROM app_quiz_attempts').get().count, 1);
});

test('tentativa reprovada não revela o gabarito e nova tentativa pode concluir a lição', async () => {
  const DB = createDatabase();
  const registration = await register(DB, {
    email: 'quiz@example.com',
    ip: '203.0.113.44',
  });
  await checkout(DB, registration.cookie, {
    'Idempotency-Key': 'checkout-quiz-student-1',
  });

  let response = await handleApplicationApi(request('/api/me/state', {
    cookie: registration.cookie,
  }), { DB, config: baseConfig });
  let progress = (await payload(response)).progress['jornada-lidere'];
  progress.lessons['licao-1'].pdfRead = true;
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  progress = (await payload(response)).progress;
  progress.lessons['licao-1'].videoCompleted = true;
  response = await handleApplicationApi(request('/api/me/progress/jornada-lidere', {
    method: 'PUT',
    cookie: registration.cookie,
    body: { progress },
  }), { DB, config: baseConfig });
  assert.equal(response.status, 200);

  response = await handleApplicationApi(request('/api/me/quiz/jornada-lidere/licao-1/attempt', {
    method: 'POST',
    cookie: registration.cookie,
    headers: { 'Idempotency-Key': 'quiz-student-licao-1-attempt-1' },
    body: { answers: { q1: 'b' }, score: 1 },
  }), { DB, config: baseConfig });
  let result = await payload(response);
  assert.equal(result.score, 0, 'a nota enviada pelo navegador deve ser ignorada');
  assert.equal(result.passed, false);
  assert.equal(result.status, 'failed');
  assert.equal(result.results.q1.isCorrect, false);
  assert.equal(Object.hasOwn(result.results.q1, 'correctOptionId'), false);

  response = await handleApplicationApi(request('/api/me/quiz/jornada-lidere/licao-1/attempt', {
    method: 'POST',
    cookie: registration.cookie,
    headers: { 'Idempotency-Key': 'quiz-student-licao-1-attempt-2' },
    body: { answers: { q1: 'a' } },
  }), { DB, config: baseConfig });
  result = await payload(response);
  assert.equal(result.score, 1);
  assert.equal(result.passed, true);
  assert.equal(result.attemptsUsed, 2);
  assert.equal(result.results.q1.correctOptionId, 'a');
  assert.equal(result.progress.lessons['licao-2'].unlocked, true);
});

test('listagem de alunos exige papel administrativo e agrega progresso por curso', async () => {
  const DB = createDatabase();
  const student = await register(DB);
  await checkout(DB, student.cookie);

  let response = await handleApplicationApi(request('/api/admin/students', {
    cookie: student.cookie,
  }), { DB, config: baseConfig });
  assert.equal(response.status, 403);
  assert.equal((await payload(response)).error.code, 'admin_required');

  const ownerConfig = {
    scryptCost: 1_024,
    authRateLimitMax: 50,
    session: {
      cookieName: '__Host-beta_session',
      cookieSecure: true,
      ttlSeconds: 86_400,
    },
    bootstrap: {
      ownerEmail: 'pastor@example.com',
    },
    features: {
      registration: true,
      demoAccess: false,
      paymentsMode: 'test',
    },
  };
  const owner = await register(DB, {
    name: 'Pastor André',
    email: 'pastor@example.com',
    password: 'senha pastoral segura',
    config: ownerConfig,
    ip: '203.0.113.30',
  });
  assert.equal(owner.body.user.role, 'owner');
  assert.match(owner.response.headers.get('set-cookie'), /^__Host-beta_session=/);

  response = await handleApplicationApi(request('/api/admin/students', {
    cookie: owner.cookie,
  }), { DB, config: ownerConfig });
  assert.equal(response.status, 200);
  const body = await payload(response);
  assert.equal(body.students.length, 1);
  assert.equal(body.students[0].email, 'maria@example.com');
  assert.deepEqual(body.students[0].progress['jornada-lidere'], {
    completedLessons: 0,
    currentLesson: 'licao-1',
    percentage: 0,
  });
});
