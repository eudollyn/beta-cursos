/* ============================================================
   BETA CURSOS — PAINEL ADMINISTRATIVO
   Módulo isolado. Inicialização: window.BetaAdmin.mount(element)
   ============================================================ */
(function () {
  'use strict';

  const LOCAL_STORAGE_KEY = 'betaAdmin.local.v1';
  const LOCAL_STORE_VERSION = 2;
  const LOCAL_FILE_LIMIT = 4 * 1024 * 1024;
  const STATUS_LABELS = {
    draft: 'Rascunho',
    published: 'Publicado',
    archived: 'Arquivado',
  };
  const LEVELS = ['Iniciante', 'Intermediário', 'Avançado'];
  const VIDEO_PROVIDERS = {
    youtube: 'YouTube',
    vimeo: 'Vimeo',
    direct: 'URL direta',
    upload: 'Vídeo enviado',
  };

  const state = {
    root: null,
    mode: 'loading',
    adapter: null,
    courses: [],
    media: [],
    students: [],
    studentsSource: 'api',
    bootstrap: {},
    view: 'overview',
    editorTab: 'details',
    editorCourse: null,
    editorOriginalId: null,
    editorIsNew: false,
    editorDirty: false,
    selectedModule: 0,
    selectedLesson: 0,
    validationErrors: [],
    courseSearch: '',
    courseStatus: 'all',
    courseCategory: 'all',
    mediaSearch: '',
    mediaKind: 'all',
    studentSearch: '',
    studentCourse: 'all',
    importedSeed: false,
    loading: false,
    busy: false,
    mobileOpen: false,
    lastFocus: null,
    beforeUnload: null,
    eventController: null,
    initError: null,
  };

  class ApiError extends Error {
    constructor(message, status, payload) {
      super(message);
      this.name = 'ApiError';
      this.status = status;
      this.payload = payload;
    }
  }

  function clone(value) {
    if (typeof structuredClone === 'function') return structuredClone(value);
    return JSON.parse(JSON.stringify(value));
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#096;');
  }

  function safeUrl(value) {
    let raw = String(value || '').trim();
    if (!raw) return '';
    if (/^\/api(?:\/|$|\?)/i.test(raw)) raw = window.BetaConfig?.mediaUrl(raw) || raw;
    if (/^data:(?:image\/|video\/|application\/pdf)/i.test(raw)) return raw;
    try {
      const parsed = new URL(raw, window.location.href);
      return ['http:', 'https:', 'blob:'].includes(parsed.protocol) ? parsed.href : '';
    } catch (_) {
      return '';
    }
  }

  function safeCssUrl(value) {
    return safeUrl(value).replace(/['"()\\\r\n]/g, character => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
  }

  function slugify(value) {
    return String(value || 'curso')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 64) || 'curso';
  }

  function uid(prefix) {
    const random = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
    return `${prefix}-${Date.now().toString(36)}-${random}`;
  }

  function money(value) {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(Number(value) || 0);
  }

  function formatBytes(bytes) {
    const size = Number(bytes) || 0;
    if (size < 1024) return `${size} B`;
    if (size < 1024 ** 2) return `${(size / 1024).toFixed(1)} KB`;
    if (size < 1024 ** 3) return `${(size / 1024 ** 2).toFixed(1)} MB`;
    return `${(size / 1024 ** 3).toFixed(1)} GB`;
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(date);
  }

  function getSeedCourses() {
    try {
      if (typeof COURSES_DATA !== 'undefined' && Array.isArray(COURSES_DATA)) {
        return clone(COURSES_DATA);
      }
    } catch (_) {
      // A constante pode não ter sido carregada na página de administração.
    }
    return [];
  }

  function newQuestion(index) {
    const optionIds = ['a', 'b', 'c', 'd'];
    return {
      id: uid(`q${index + 1}`),
      question: '',
      options: optionIds.map(id => ({ id, text: '' })),
      correctOptionId: 'a',
      explanation: '',
    };
  }

  function normalizeQuestion(question, index) {
    const value = clone(question || {});
    const optionIds = ['a', 'b', 'c', 'd'];
    const sourceOptions = Array.isArray(value.options) ? value.options.slice(0, 4) : [];
    while (sourceOptions.length < 4) sourceOptions.push({});
    value.id = value.id || uid(`q${index + 1}`);
    value.question = value.question || '';
    value.options = sourceOptions.map((option, optionIndex) => ({
      id: optionIds[optionIndex],
      text: option?.text || '',
    }));
    value.correctOptionId = optionIds.includes(value.correctOptionId)
      ? value.correctOptionId
      : 'a';
    value.explanation = value.explanation || '';
    return value;
  }

  function normalizeLesson(lesson, index) {
    const value = clone(lesson || {});
    value.id = value.id || uid('licao');
    value.order = index + 1;
    value.title = value.title || `Lição ${index + 1}`;
    value.description = value.description || '';
    value.pdfUrl = value.pdfUrl || '';
    value.pdfTitle = value.pdfTitle || '';
    value.pdfMediaId = value.pdfMediaId || null;
    value.videoProvider = value.videoProvider || 'youtube';
    value.videoUrl = value.videoUrl || '';
    value.videoEmbedId = value.videoEmbedId || '';
    value.videoMediaId = value.videoMediaId || null;
    value.videoTitle = value.videoTitle || '';
    value.quiz = Array.isArray(value.quiz)
      ? value.quiz.map(normalizeQuestion)
      : [];
    value.quizConfig = {
      passingScore: Number(value.quizConfig?.passingScore ?? 4),
      maxAttempts: Number(value.quizConfig?.maxAttempts ?? 3),
      shuffleQuestions: value.quizConfig?.shuffleQuestions !== false,
      shuffleOptions: value.quizConfig?.shuffleOptions !== false,
    };
    return value;
  }

  function normalizeModule(module, index) {
    const value = clone(module || {});
    value.id = value.id || uid('modulo');
    value.order = index + 1;
    value.title = value.title || `Módulo ${index + 1}`;
    value.description = value.description || '';
    value.lessons = Array.isArray(value.lessons)
      ? value.lessons.map(normalizeLesson)
      : [];
    return value;
  }

  function normalizeCourse(course, options) {
    const config = options || {};
    const value = clone(course || {});
    value.id = value.id || slugify(value.title) || uid('curso');
    value.title = value.title || 'Novo curso';
    value.slug = value.slug || slugify(value.title);
    value.subtitle = value.subtitle || '';
    value.description = value.description || '';
    value.status = value.status || (config.seedPublished ? 'published' : 'draft');
    if (!STATUS_LABELS[value.status]) value.status = 'draft';
    value.category = value.category || '';
    value.level = value.level || 'Iniciante';
    value.duration = value.duration || '';
    value.coverImage = value.coverImage || '';
    value.coverMediaId = value.coverMediaId || null;
    value.featured = Boolean(value.featured);
    value.pricing = {
      fullPrice: Number(value.pricing?.fullPrice ?? 0),
      memberDiscount: Number(value.pricing?.memberDiscount ?? 0),
      discountPercent: Number(
        value.pricing?.discountPercent ?? ((value.pricing?.memberDiscount || 0) * 100),
      ),
      currency: value.pricing?.currency || 'BRL',
      mode: value.pricing?.mode || 'production',
      installments: Array.isArray(value.pricing?.installments)
        ? value.pricing.installments
        : [1, 2, 3, 6, 12],
      paymentMethods: Array.isArray(value.pricing?.paymentMethods)
        ? value.pricing.paymentMethods
        : ['credit_card', 'pix', 'boleto'],
    };
    value.modules = Array.isArray(value.modules)
      ? value.modules.map(normalizeModule)
      : [];
    value.createdAt = value.createdAt || new Date().toISOString();
    value.updatedAt = value.updatedAt || new Date().toISOString();
    return value;
  }

  function createBlankLesson(index) {
    return normalizeLesson({
      title: `Lição ${index + 1}`,
      quiz: Array.from({ length: 5 }, (_, questionIndex) => newQuestion(questionIndex)),
      quizConfig: {
        passingScore: 4,
        maxAttempts: 3,
        shuffleQuestions: true,
        shuffleOptions: true,
      },
    }, index);
  }

  function createBlankModule(index) {
    return normalizeModule({
      title: `Módulo ${index + 1}`,
      lessons: [createBlankLesson(0)],
    }, index);
  }

  function createBlankCourse() {
    return normalizeCourse({
      id: uid('curso'),
      title: 'Novo curso',
      status: 'draft',
      level: 'Iniciante',
      pricing: { fullPrice: 0, memberDiscount: 0, discountPercent: 0 },
      modules: [createBlankModule(0)],
    });
  }

  function renewNestedIds(course) {
    const value = clone(course);
    delete value.revision;
    value.id = `${slugify(value.title)}-copia-${Date.now().toString(36)}`;
    value.modules.forEach(module => {
      module.id = uid('modulo');
      module.lessons.forEach(lesson => {
        lesson.id = uid('licao');
        lesson.quiz.forEach((question, index) => {
          question.id = uid(`q${index + 1}`);
        });
      });
    });
    return value;
  }

  function getPath(object, path) {
    return String(path).split('.').reduce((current, key) => current?.[key], object);
  }

  function setPath(object, path, nextValue) {
    const parts = String(path).split('.');
    let current = object;
    parts.slice(0, -1).forEach(part => {
      current = current[part];
    });
    current[parts.at(-1)] = nextValue;
  }

  function reorder(items, from, to) {
    if (to < 0 || to >= items.length || from === to) return false;
    const [item] = items.splice(from, 1);
    items.splice(to, 0, item);
    items.forEach((entry, index) => { entry.order = index + 1; });
    return true;
  }

  async function apiRequest(url, options) {
    let response;
    try {
      const endpoint = window.BetaConfig?.apiUrl(url) || url;
      const authorization = await (window.BetaConfig?.authorizationHeaders?.() || {});
      response = await fetch(endpoint, {
        ...(options || {}),
        credentials: window.BetaConfig?.credentialsFor(url) || 'same-origin',
        headers: {
          Accept: 'application/json',
          'X-Requested-With': 'BetaCursosAdmin',
          ...authorization,
          ...(options?.headers || {}),
        },
      });
    } catch (error) {
      throw new ApiError('O servidor administrativo não está disponível.', 0, error);
    }

    const contentType = response.headers.get('content-type') || '';
    let payload = null;
    if (response.status !== 204) {
      if (contentType.includes('application/json')) {
        payload = await response.json().catch(() => null);
      } else {
        payload = await response.text().catch(() => '');
      }
    }
    if (!response.ok) {
      const message = payload?.message
        || payload?.error?.message
        || (typeof payload?.error === 'string' ? payload.error : '')
        || `Não foi possível concluir a operação (${response.status}).`;
      throw new ApiError(message, response.status, payload);
    }
    return payload;
  }

  function unwrapCollection(payload, key) {
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload?.[key])) return payload[key];
    if (Array.isArray(payload?.data?.[key])) return payload.data[key];
    if (Array.isArray(payload?.data)) return payload.data;
    if (Array.isArray(payload?.items)) return payload.items;
    return [];
  }

  function unwrapEntity(payload, key) {
    return payload?.[key] || payload?.data?.[key] || payload?.data || payload;
  }

  const remoteAdapter = {
    async bootstrap() {
      const payload = await apiRequest('/api/admin/bootstrap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      });
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
        throw new ApiError('O endpoint administrativo não está disponível nesta instalação.', 503, payload);
      }
      return payload;
    },
    async listCourses() {
      const payload = await apiRequest('/api/admin/courses');
      if (!Array.isArray(payload) && (!payload || typeof payload !== 'object')) {
        throw new ApiError('A resposta da lista de cursos é inválida.', 502, payload);
      }
      return unwrapCollection(payload, 'courses').map(course => normalizeCourse(course));
    },
    async getCourse(id) {
      const payload = await apiRequest(`/api/admin/courses/${encodeURIComponent(id)}`);
      return normalizeCourse(unwrapEntity(payload, 'course'));
    },
    async createCourse(course) {
      const payload = await apiRequest('/api/admin/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(course),
      });
      return normalizeCourse(unwrapEntity(payload, 'course') || course);
    },
    async updateCourse(id, course) {
      const updatePayload = { ...course };
      if (Object.prototype.hasOwnProperty.call(course, 'revision')) {
        updatePayload.revision = course.revision;
      }
      const payload = await apiRequest(`/api/admin/courses/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatePayload),
      });
      if (!payload) return remoteAdapter.getCourse(id);
      return normalizeCourse(unwrapEntity(payload, 'course') || course);
    },
    async deleteCourse(id) {
      return apiRequest(`/api/admin/courses/${encodeURIComponent(id)}`, { method: 'DELETE' });
    },
    async uploadMedia(file, kind) {
      const form = new FormData();
      form.append('file', file);
      form.append('kind', kind || mediaKindFromType(file.type));
      const payload = await apiRequest('/api/admin/media', { method: 'POST', body: form });
      return normalizeMedia(unwrapEntity(payload, 'media'), file);
    },
    async deleteMedia(id) {
      return apiRequest(`/api/admin/media/${encodeURIComponent(id)}`, { method: 'DELETE' });
    },
    async listMedia() {
      const payload = await apiRequest('/api/admin/media');
      if (!Array.isArray(payload) && (!payload || typeof payload !== 'object')) {
        throw new ApiError('A resposta da biblioteca de mídia é inválida.', 502, payload);
      }
      return unwrapCollection(payload, 'media').map(item => normalizeMedia(item));
    },
    async listStudents() {
      const payload = await apiRequest('/api/admin/students');
      if (!Array.isArray(payload) && (!payload || typeof payload !== 'object')) {
        throw new ApiError('A resposta da lista de alunos é inválida.', 502, payload);
      }
      return unwrapCollection(payload, 'students');
    },
    async exportData() {
      return apiRequest('/api/admin/export');
    },
    async importData(data) {
      return apiRequest('/api/admin/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          mode: 'replace',
          confirm: 'SUBSTITUIR',
        }),
      });
    },
  };

  function readLocalStore() {
    try {
      const parsed = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || 'null');
      if (parsed && Array.isArray(parsed.courses) && Array.isArray(parsed.media)) {
        if (Number(parsed.version || 1) < LOCAL_STORE_VERSION) {
          parsed.courses = parsed.courses.map(course => {
            const value = clone(course);
            const isLegacyLiderePrice = value.id === 'jornada-lidere'
              && Number(value.pricing?.fullPrice) === 19.90
              && (Number(value.pricing?.memberDiscount) === 0.30
                || Number(value.pricing?.discountPercent) === 30);
            if (isLegacyLiderePrice) {
              value.pricing.memberDiscount = 0;
              value.pricing.discountPercent = 0;
            }
            return value;
          });
          parsed.version = LOCAL_STORE_VERSION;
          writeLocalStore(parsed);
        }
        return parsed;
      }
    } catch (_) {
      // Um armazenamento local inválido é reiniciado sem afetar dados do servidor.
    }
    const initial = {
      version: LOCAL_STORE_VERSION,
      courses: getSeedCourses().map(course => normalizeCourse(course, { seedPublished: true })),
      media: [],
      updatedAt: new Date().toISOString(),
    };
    writeLocalStore(initial);
    return initial;
  }

  function writeLocalStore(data) {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({
      ...data,
      version: LOCAL_STORE_VERSION,
      updatedAt: new Date().toISOString(),
    }));
  }

  const localAdapter = {
    async bootstrap() {
      const data = readLocalStore();
      return { courses: data.courses, media: data.media, local: true };
    },
    async listCourses() {
      return readLocalStore().courses.map(course => normalizeCourse(course));
    },
    async getCourse(id) {
      const course = readLocalStore().courses.find(item => item.id === id);
      if (!course) throw new ApiError('Curso não encontrado.', 404);
      return normalizeCourse(course);
    },
    async createCourse(course) {
      const store = readLocalStore();
      const value = normalizeCourse(course);
      if (store.courses.some(item => item.id === value.id)) value.id = `${value.id}-${Date.now().toString(36)}`;
      value.revision = 1;
      value.createdAt = new Date().toISOString();
      value.updatedAt = value.createdAt;
      store.courses.push(value);
      writeLocalStore(store);
      return value;
    },
    async updateCourse(id, course) {
      const store = readLocalStore();
      const index = store.courses.findIndex(item => item.id === id);
      if (index < 0) throw new ApiError('Curso não encontrado.', 404);
      const value = normalizeCourse({ ...course, updatedAt: new Date().toISOString() });
      value.revision = Number(store.courses[index].revision || 0) + 1;
      store.courses[index] = value;
      writeLocalStore(store);
      return value;
    },
    async deleteCourse(id) {
      const store = readLocalStore();
      store.courses = store.courses.filter(item => item.id !== id);
      writeLocalStore(store);
      return { ok: true };
    },
    async uploadMedia(file, kind) {
      if (file.size > LOCAL_FILE_LIMIT) {
        throw new ApiError('No modo local, arquivos devem ter até 4 MB. Para vídeos maiores, use um link ou conecte o servidor.', 413);
      }
      const url = await fileToDataUrl(file);
      const store = readLocalStore();
      const media = normalizeMedia({
        id: uid('midia'),
        name: file.name,
        filename: file.name,
        type: file.type,
        kind: kind || mediaKindFromType(file.type),
        size: file.size,
        url,
        createdAt: new Date().toISOString(),
      }, file);
      store.media.unshift(media);
      writeLocalStore(store);
      return media;
    },
    async deleteMedia(id) {
      const store = readLocalStore();
      store.media = store.media.filter(item => item.id !== id);
      writeLocalStore(store);
      return { ok: true };
    },
    async listMedia() {
      return readLocalStore().media.map(item => normalizeMedia(item));
    },
    async listStudents() {
      return getAdminStudents() || [];
    },
    async exportData() {
      return readLocalStore();
    },
    async importData(data) {
      const normalized = normalizeBackup(data);
      writeLocalStore(normalized);
      return normalized;
    },
  };

  function mediaKindFromType(type) {
    if (String(type).includes('pdf')) return 'pdf';
    if (String(type).startsWith('video/')) return 'video';
    if (String(type).startsWith('image/')) return 'image';
    return 'document';
  }

  function normalizeMedia(media, file) {
    const value = media || {};
    return {
      id: value.id || uid('midia'),
      name: value.name || value.filename || file?.name || 'Arquivo',
      filename: value.filename || value.name || file?.name || 'arquivo',
      type: value.type || value.contentType || file?.type || 'application/octet-stream',
      kind: value.kind || mediaKindFromType(value.type || value.contentType || file?.type),
      size: Number(value.size ?? file?.size ?? 0),
      url: value.url || value.publicUrl || value.downloadUrl || '',
      createdAt: value.createdAt || new Date().toISOString(),
    };
  }

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new ApiError('Não foi possível ler o arquivo.', 0));
      reader.readAsDataURL(file);
    });
  }

  function normalizeBackup(data) {
    const source = data?.data || data || {};
    const rawCourses = Array.isArray(source) ? source : source.courses;
    if (!Array.isArray(rawCourses)) {
      throw new ApiError('Backup inválido: a lista de cursos não foi encontrada.', 400);
    }
    return {
      version: 1,
      courses: rawCourses.map(course => normalizeCourse(course)),
      media: Array.isArray(source.media) ? source.media.map(item => normalizeMedia(item)) : [],
      updatedAt: new Date().toISOString(),
    };
  }

  function dispatchCoursesChanged() {
    window.dispatchEvent(new CustomEvent('beta:courses-changed', {
      detail: {
        courses: clone(state.courses),
        source: state.mode,
      },
    }));
  }

  function normalizeVideoUrl(rawValue, selectedProvider) {
    const raw = String(rawValue || '').trim();
    if (!raw) return { provider: selectedProvider || 'youtube', url: '', embedId: '' };
    if (/^\/api\/media\/[a-zA-Z0-9_-]{8,100}$/.test(raw)) {
      return { provider: 'upload', url: raw, embedId: '' };
    }
    let url;
    try {
      const candidate = /^(?:https?|data|blob):/i.test(raw)
        ? raw
        : /^(?:\/|\.\/|\.\.\/)/.test(raw)
          ? new URL(raw, window.location.href).href
          : `https://${raw}`;
      url = new URL(candidate);
    } catch (_) {
      return { provider: selectedProvider || 'direct', url: raw, embedId: '', invalid: true };
    }
    if (['data:', 'blob:'].includes(url.protocol)) {
      const isUploadedVideo = selectedProvider === 'upload' && (url.protocol === 'blob:' || /^data:video\//i.test(raw));
      return { provider: 'upload', url: raw, embedId: '', invalid: !isUploadedVideo };
    }
    if (!['http:', 'https:'].includes(url.protocol)) {
      return { provider: selectedProvider || 'direct', url: raw, embedId: '', invalid: true };
    }
    const host = url.hostname.toLowerCase().replace(/^www\./, '');

    if (host === 'youtu.be' || host.endsWith('youtube.com') || host.endsWith('youtube-nocookie.com')) {
      let id = '';
      if (host === 'youtu.be') id = url.pathname.split('/').filter(Boolean)[0] || '';
      if (!id) id = url.searchParams.get('v') || '';
      if (!id) {
        const parts = url.pathname.split('/').filter(Boolean);
        const marker = parts.findIndex(part => ['embed', 'shorts', 'live'].includes(part));
        if (marker >= 0) id = parts[marker + 1] || '';
      }
      id = id.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 32);
      const validId = /^[A-Za-z0-9_-]{11}$/.test(id);
      return {
        provider: 'youtube',
        url: validId ? `https://www.youtube.com/watch?v=${id}` : raw,
        embedId: validId ? id : '',
        invalid: !validId,
      };
    }

    if (host === 'vimeo.com' || host.endsWith('.vimeo.com')) {
      const id = (url.pathname.match(/(?:video\/)?(\d{6,15})/) || [])[1] || '';
      return {
        provider: 'vimeo',
        url: id ? `https://vimeo.com/${id}` : raw,
        embedId: id,
        invalid: !id,
      };
    }

    return { provider: selectedProvider === 'upload' ? 'upload' : 'direct', url: url.href, embedId: '' };
  }

  function validateCourse(course) {
    const errors = [];
    function add(path, message) { errors.push({ path, message }); }
    if (!course.title.trim()) add('title', 'Informe o nome do curso.');
    if (!course.description.trim()) add('description', 'Escreva a descrição do curso.');
    if (!course.category.trim()) add('category', 'Informe a categoria.');
    if (!course.level.trim()) add('level', 'Informe o nível.');
    if (!course.duration.trim()) add('duration', 'Informe a duração.');
    if (Number(course.pricing.fullPrice) < 0) add('pricing.fullPrice', 'O preço não pode ser negativo.');
    if (Number(course.pricing.discountPercent) < 0 || Number(course.pricing.discountPercent) > 100) {
      add('pricing.discountPercent', 'O desconto deve estar entre 0% e 100%.');
    }
    if (!course.modules.length) add('modules', 'Adicione ao menos um módulo.');

    course.modules.forEach((module, moduleIndex) => {
      const modulePrefix = `modules.${moduleIndex}`;
      if (!module.title.trim()) add(`${modulePrefix}.title`, `Dê um nome ao módulo ${moduleIndex + 1}.`);
      if (!module.lessons.length) add(`${modulePrefix}.lessons`, `O módulo ${moduleIndex + 1} precisa ter ao menos uma lição.`);
      module.lessons.forEach((lesson, lessonIndex) => {
        const lessonName = lesson.title || `Lição ${lessonIndex + 1}`;
        const prefix = `${modulePrefix}.lessons.${lessonIndex}`;
        if (!lesson.title.trim()) add(`${prefix}.title`, `Informe o título da lição ${lessonIndex + 1}.`);
        if (!lesson.description.trim()) add(`${prefix}.description`, `${lessonName}: escreva uma descrição.`);
        if (!lesson.pdfUrl.trim()) add(`${prefix}.pdfUrl`, `${lessonName}: importe a apostila em PDF.`);
        const normalizedVideo = normalizeVideoUrl(lesson.videoUrl, lesson.videoProvider);
        const hasUploadedVideo = lesson.videoProvider === 'upload' && Boolean(lesson.videoUrl);
        if ((!lesson.videoUrl && !lesson.videoEmbedId) || (normalizedVideo.invalid && !hasUploadedVideo)) {
          add(`${prefix}.videoUrl`, `${lessonName}: configure um vídeo válido.`);
        }
        if (lesson.quiz.length !== 5) {
          add(`${prefix}.quiz`, `${lessonName}: o teste deve ter exatamente 5 questões.`);
        }
        if (Number(lesson.quizConfig.passingScore) < 1 || Number(lesson.quizConfig.passingScore) > 5) {
          add(`${prefix}.quizConfig.passingScore`, `${lessonName}: a nota mínima deve estar entre 1 e 5.`);
        }
        if (Number(lesson.quizConfig.maxAttempts) < 1) {
          add(`${prefix}.quizConfig.maxAttempts`, `${lessonName}: informe ao menos uma tentativa.`);
        }
        lesson.quiz.forEach((question, questionIndex) => {
          const questionPrefix = `${prefix}.quiz.${questionIndex}`;
          if (!question.question.trim()) add(`${questionPrefix}.question`, `${lessonName}, questão ${questionIndex + 1}: escreva o enunciado.`);
          if (!Array.isArray(question.options) || question.options.length !== 4) {
            add(`${questionPrefix}.options`, `${lessonName}, questão ${questionIndex + 1}: são necessárias 4 alternativas.`);
          } else if (question.options.some(option => !option.text.trim())) {
            add(`${questionPrefix}.options`, `${lessonName}, questão ${questionIndex + 1}: preencha as 4 alternativas.`);
          }
          if (!question.options.some(option => option.id === question.correctOptionId)) {
            add(`${questionPrefix}.correctOptionId`, `${lessonName}, questão ${questionIndex + 1}: marque a resposta correta.`);
          }
        });
      });
    });
    return errors;
  }

  function readiness(course) {
    const errors = validateCourse(course);
    const totalLessons = course.modules.reduce((sum, module) => sum + module.lessons.length, 0);
    const totalQuestions = course.modules.reduce(
      (sum, module) => sum + module.lessons.reduce((lessonSum, lesson) => lessonSum + lesson.quiz.length, 0),
      0,
    );
    return { errors, ready: errors.length === 0, totalLessons, totalQuestions };
  }

  function shellTemplate() {
    return `
      <div class="beta-admin" data-ba-app>
        <a class="ba-skip-link" href="#ba-main">Pular para o conteúdo</a>
        <header class="ba-mobile-header">
          <div class="ba-brand" aria-label="Beta Cursos">
            <span class="ba-brand__beta">Beta</span><span class="ba-brand__cursos">cursos</span>
          </div>
          <button class="ba-icon-button" type="button" data-action="toggle-menu" aria-expanded="false" aria-controls="ba-sidebar">Menu</button>
        </header>
        <div class="ba-layout">
          <aside id="ba-sidebar" class="ba-sidebar" aria-label="Navegação administrativa">
            <div class="ba-sidebar__brand">
              <div class="ba-brand"><span class="ba-brand__beta">Beta</span><span class="ba-brand__cursos">cursos</span></div>
              <span class="ba-sidebar__eyebrow">Administração</span>
            </div>
            <nav class="ba-nav">
              ${navButton('overview', '01', 'Visão geral')}
              ${navButton('courses', '02', 'Cursos')}
              ${navButton('media', '03', 'Mídia')}
              ${navButton('students', '04', 'Alunos')}
              ${navButton('backup', '05', 'Backup e configurações')}
            </nav>
            <div class="ba-sidebar__footer">
              <span class="ba-connection" data-ba-connection><i></i> Conectando…</span>
              <button type="button" class="ba-link-button" data-action="leave-admin">Voltar ao site</button>
            </div>
          </aside>
          <button class="ba-backdrop" type="button" data-action="close-menu" aria-label="Fechar menu"></button>
          <main id="ba-main" class="ba-main" tabindex="-1">
            <div id="ba-mode-banner"></div>
            <div id="ba-view" aria-live="polite"></div>
          </main>
        </div>
        <div class="ba-toast-region" data-ba-toasts role="status" aria-live="polite" aria-atomic="true"></div>
        <div class="ba-modal-layer" data-ba-modal></div>
      </div>
    `;
  }

  function navButton(view, number, label) {
    return `<button type="button" class="ba-nav__item" data-view="${view}">
      <span class="ba-nav__number" aria-hidden="true">${number}</span><span>${label}</span>
    </button>`;
  }

  function renderModeBanner() {
    const banner = state.root.querySelector('#ba-mode-banner');
    const connection = state.root.querySelector('[data-ba-connection]');
    if (state.mode === 'local') {
      banner.innerHTML = `<div class="ba-banner ba-banner--warning" role="status">
        <strong>Modo local de desenvolvimento.</strong>
        As alterações ficam somente neste navegador porque o servidor administrativo não respondeu. Não use este modo para operar a plataforma com alunos reais.
      </div>`;
      connection.innerHTML = '<i></i> Modo local';
      connection.classList.add('is-local');
      connection.classList.remove('is-error');
    } else if (state.mode === 'api') {
      banner.innerHTML = state.importedSeed
        ? `<div class="ba-banner ba-banner--success" role="status"><strong>Jornada Lidere importada.</strong> O curso demonstrativo foi copiado para o servidor como conteúdo inicial publicado.</div>`
        : '';
      connection.innerHTML = '<i></i> Servidor conectado';
      connection.classList.remove('is-local', 'is-error');
    } else if (state.mode === 'error' || state.mode === 'denied') {
      banner.innerHTML = '';
      connection.innerHTML = `<i></i> ${state.mode === 'denied' ? 'Acesso restrito' : 'Sem conexão'}`;
      connection.classList.remove('is-local');
      connection.classList.add('is-error');
    } else {
      banner.innerHTML = '';
      connection.innerHTML = '<i></i> Conectando…';
      connection.classList.remove('is-local', 'is-error');
    }
  }

  function pageHeader(eyebrow, title, description, actions) {
    return `<header class="ba-page-header">
      <div>
        <div class="ba-eyebrow">${escapeHtml(eyebrow)}</div>
        <h1>${escapeHtml(title)}</h1>
        ${description ? `<p>${escapeHtml(description)}</p>` : ''}
      </div>
      ${actions ? `<div class="ba-page-actions">${actions}</div>` : ''}
    </header>`;
  }

  function statusBadge(status) {
    const safeStatus = STATUS_LABELS[status] ? status : 'draft';
    return `<span class="ba-status ba-status--${safeStatus}"><i></i>${STATUS_LABELS[safeStatus]}</span>`;
  }

  function render() {
    if (!state.root) return;
    renderModeBanner();
    state.root.querySelectorAll('[data-view]').forEach(button => {
      const active = button.dataset.view === state.view;
      button.classList.toggle('is-active', active);
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
    const view = state.root.querySelector('#ba-view');
    if (state.loading) {
      view.innerHTML = `<div class="ba-loading" role="status"><span></span><p>Preparando o painel…</p></div>`;
      return;
    }
    if (state.initError) {
      const denied = state.mode === 'denied';
      view.innerHTML = `${pageHeader(denied ? 'Acesso restrito' : 'Serviço administrativo', 'Não foi possível abrir o painel', denied ? 'Sua sessão não tem permissão administrativa ou expirou.' : 'Não foi possível carregar os dados administrativos.')}<section class="ba-panel">${emptyState(denied ? 'Acesso administrativo necessário' : 'Painel temporariamente indisponível', state.initError.message || (denied ? 'Entre novamente com uma conta autorizada.' : 'Verifique a conexão e tente novamente.'))}</section>`;
      return;
    }
    switch (state.view) {
      case 'courses': view.innerHTML = coursesTemplate(); break;
      case 'editor': view.innerHTML = editorTemplate(); break;
      case 'media': view.innerHTML = mediaTemplate(); break;
      case 'students': view.innerHTML = studentsTemplate(); break;
      case 'backup': view.innerHTML = backupTemplate(); break;
      default: view.innerHTML = overviewTemplate();
    }
    updateDirtyIndicator();
  }

  function overviewTemplate() {
    const published = state.courses.filter(course => course.status === 'published').length;
    const drafts = state.courses.filter(course => course.status === 'draft').length;
    const lessons = state.courses.reduce(
      (sum, course) => sum + course.modules.reduce((moduleSum, module) => moduleSum + module.lessons.length, 0),
      0,
    );
    const incomplete = state.courses.filter(course => !readiness(course).ready);
    const recent = [...state.courses]
      .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0))
      .slice(0, 5);
    return `
      ${pageHeader('Centro de formação', 'Visão geral', 'Acompanhe o conteúdo, a publicação e a preparação dos cursos.', '<button class="ba-button ba-button--primary" type="button" data-action="new-course">Criar curso</button>')}
      <section class="ba-stat-grid" aria-label="Resumo da plataforma">
        ${statCard('Cursos publicados', published, 'Disponíveis para os alunos')}
        ${statCard('Rascunhos', drafts, 'Em preparação')}
        ${statCard('Lições', lessons, 'Em todos os cursos')}
        ${statCard('Arquivos', state.media.length, 'Na biblioteca de mídia')}
      </section>
      <div class="ba-overview-grid">
        <section class="ba-panel">
          <div class="ba-panel__header"><div><span class="ba-eyebrow">Conteúdo</span><h2>Cursos recentes</h2></div><button class="ba-link-button" type="button" data-view="courses">Ver todos</button></div>
          ${recent.length ? `<div class="ba-compact-list">${recent.map(course => {
            const info = readiness(course);
            return `<button type="button" class="ba-compact-course" data-action="edit-course" data-course-id="${escapeAttr(course.id)}">
              <span class="ba-course-monogram">${escapeHtml(course.title.slice(0, 2).toUpperCase())}</span>
              <span class="ba-compact-course__body"><strong>${escapeHtml(course.title)}</strong><small>${info.totalLessons} lições · Atualizado em ${escapeHtml(formatDate(course.updatedAt))}</small></span>
              ${statusBadge(course.status)}
            </button>`;
          }).join('')}</div>` : emptyState('Nenhum curso criado', 'Crie o primeiro curso da plataforma para começar.')}
        </section>
        <aside class="ba-panel ba-readiness">
          <div class="ba-panel__header"><div><span class="ba-eyebrow">Qualidade</span><h2>Preparação para publicar</h2></div></div>
          ${incomplete.length ? `
            <p class="ba-muted">${incomplete.length} curso${incomplete.length > 1 ? 's precisam' : ' precisa'} de revisão antes da publicação.</p>
            <div class="ba-readiness-list">${incomplete.slice(0, 4).map(course => {
              const count = readiness(course).errors.length;
              return `<button type="button" data-action="edit-course" data-course-id="${escapeAttr(course.id)}"><span>${escapeHtml(course.title)}</span><strong>${count} pendência${count > 1 ? 's' : ''}</strong></button>`;
            }).join('')}</div>`
            : `<div class="ba-success-state"><span aria-hidden="true">✓</span><strong>Conteúdo em ordem</strong><p>Todos os cursos atendem aos critérios de publicação.</p></div>`}
        </aside>
      </div>
      <section class="ba-callout">
        <div><span class="ba-eyebrow">Próximo passo</span><h2>Construa uma jornada completa</h2><p>Organize apostila, vídeo e teste em cada lição. O painel verifica tudo antes de colocar o curso no ar.</p></div>
        <button type="button" class="ba-button ba-button--outline" data-action="new-course">Novo curso</button>
      </section>`;
  }

  function statCard(label, value, detail) {
    return `<article class="ba-stat-card"><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span><small>${escapeHtml(detail)}</small></article>`;
  }

  function coursesTemplate() {
    const categories = [...new Set(state.courses.map(course => course.category).filter(Boolean))].sort();
    const term = state.courseSearch.trim().toLocaleLowerCase('pt-BR');
    const courses = state.courses.filter(course => {
      const matchesSearch = !term || `${course.title} ${course.subtitle} ${course.category}`.toLocaleLowerCase('pt-BR').includes(term);
      const matchesStatus = state.courseStatus === 'all' || course.status === state.courseStatus;
      const matchesCategory = state.courseCategory === 'all' || course.category === state.courseCategory;
      return matchesSearch && matchesStatus && matchesCategory;
    });
    return `
      ${pageHeader('Catálogo', 'Cursos', 'Crie, organize e publique as formações da igreja.', '<button class="ba-button ba-button--primary" type="button" data-action="new-course">Criar curso</button>')}
      <section class="ba-toolbar" aria-label="Filtros de cursos">
        <label class="ba-search"><span class="ba-sr-only">Buscar cursos</span><input type="search" data-filter="course-search" value="${escapeAttr(state.courseSearch)}" placeholder="Buscar por nome ou categoria…"><i aria-hidden="true">⌕</i></label>
        <label><span class="ba-sr-only">Filtrar por situação</span><select data-filter="course-status">
          ${selectOption('all', state.courseStatus, 'Todas as situações')}
          ${selectOption('draft', state.courseStatus, 'Rascunhos')}
          ${selectOption('published', state.courseStatus, 'Publicados')}
          ${selectOption('archived', state.courseStatus, 'Arquivados')}
        </select></label>
        <label><span class="ba-sr-only">Filtrar por categoria</span><select data-filter="course-category">
          ${selectOption('all', state.courseCategory, 'Todas as categorias')}
          ${categories.map(category => selectOption(category, state.courseCategory, category)).join('')}
        </select></label>
        <span class="ba-result-count">${courses.length} de ${state.courses.length}</span>
      </section>
      ${courses.length ? `<div class="ba-course-grid">${courses.map(courseCard).join('')}</div>` : emptyState('Nenhum curso encontrado', 'Ajuste os filtros ou crie uma nova formação.')}
    `;
  }

  function courseCard(course) {
    const info = readiness(course);
    const discount = Number(course.pricing.discountPercent) || 0;
    return `<article class="ba-course-card">
      <div class="ba-course-card__cover" ${safeUrl(course.coverImage) ? `style="background-image:url('${escapeAttr(safeCssUrl(course.coverImage))}')"` : ''}>
        ${course.coverImage ? '' : `<span>${escapeHtml(course.title.slice(0, 2).toUpperCase())}</span>`}
        <div class="ba-course-card__status">${statusBadge(course.status)}</div>
      </div>
      <div class="ba-course-card__body">
        <div class="ba-course-card__meta"><span>${escapeHtml(course.category || 'Sem categoria')}</span><span>${escapeHtml(course.level)}</span></div>
        <h2>${escapeHtml(course.title)}</h2>
        <p>${escapeHtml(course.subtitle || course.description || 'Descrição ainda não informada.')}</p>
        <div class="ba-course-card__facts">
          <span>${info.totalLessons} lições</span><span>${info.totalQuestions} questões</span><span>${money(course.pricing.fullPrice)}${discount ? ` · ${discount}% desc.` : ''}</span>
        </div>
        <div class="ba-course-card__readiness ${info.ready ? 'is-ready' : ''}">
          <span>${info.ready ? '✓ Pronto para publicar' : `${info.errors.length} pendência${info.errors.length > 1 ? 's' : ''}`}</span>
        </div>
      </div>
      <footer class="ba-course-card__actions">
        <button type="button" class="ba-button ba-button--small ba-button--outline" data-action="edit-course" data-course-id="${escapeAttr(course.id)}">Editar</button>
        <div class="ba-menu-wrap">
          <button type="button" class="ba-icon-button" data-action="toggle-card-menu" aria-expanded="false" aria-label="Mais ações para ${escapeAttr(course.title)}">•••</button>
          <div class="ba-card-menu" hidden>
            <button type="button" data-action="duplicate-course" data-course-id="${escapeAttr(course.id)}">Duplicar</button>
            ${course.status === 'archived'
              ? `<button type="button" data-action="change-course-status" data-status="draft" data-course-id="${escapeAttr(course.id)}">Restaurar como rascunho</button>`
              : `<button type="button" data-action="change-course-status" data-status="archived" data-course-id="${escapeAttr(course.id)}">Arquivar</button>`}
            ${course.status === 'draft' ? `<button type="button" class="is-danger" data-action="delete-course" data-course-id="${escapeAttr(course.id)}">Excluir</button>` : ''}
          </div>
        </div>
      </footer>
    </article>`;
  }

  function editorTemplate() {
    const course = state.editorCourse;
    if (!course) return emptyState('Curso não carregado', 'Volte para a lista e selecione um curso.');
    const info = readiness(course);
    const title = state.editorIsNew ? 'Criar curso' : course.title;
    const actions = `
      <span class="ba-save-state" data-ba-save-state aria-live="polite">${state.editorDirty ? 'Alterações não salvas' : 'Tudo salvo'}</span>
      <button class="ba-button ba-button--ghost" type="button" data-action="validate-course">Verificar</button>
      <button class="ba-button ba-button--outline" type="button" data-action="save-course">Salvar</button>
      ${course.status === 'published'
        ? '<button class="ba-button ba-button--secondary" type="button" data-action="unpublish-course">Voltar a rascunho</button>'
        : '<button class="ba-button ba-button--primary" type="button" data-action="publish-course">Publicar</button>'}`;
    return `
      <div class="ba-editor-top">
        <button type="button" class="ba-back-button" data-action="back-to-courses">← Cursos</button>
        ${pageHeader(state.editorIsNew ? 'Novo conteúdo' : STATUS_LABELS[course.status], title, state.editorIsNew ? 'Preencha os dados e salve o rascunho.' : `Última atualização: ${formatDate(course.updatedAt)}`, actions)}
      </div>
      ${state.validationErrors.length ? validationSummary(state.validationErrors) : ''}
      <div class="ba-editor-tabs" role="tablist" aria-label="Seções do curso">
        ${editorTabButton('details', 'Informações')}
        ${editorTabButton('content', `Conteúdo (${info.totalLessons})`)}
        ${editorTabButton('settings', 'Publicação e preço')}
      </div>
      <div class="ba-editor-panel" role="tabpanel">
        ${state.editorTab === 'content' ? editorContentTemplate(course) : state.editorTab === 'settings' ? editorSettingsTemplate(course) : editorDetailsTemplate(course)}
      </div>`;
  }

  function editorTabButton(tab, label) {
    const active = state.editorTab === tab;
    return `<button type="button" role="tab" aria-selected="${active}" class="${active ? 'is-active' : ''}" data-editor-tab="${tab}">${escapeHtml(label)}</button>`;
  }

  function validationSummary(errors) {
    return `<section class="ba-validation" tabindex="-1" data-ba-validation role="alert">
      <div><strong>Revise ${errors.length} ${errors.length === 1 ? 'item' : 'itens'} antes de publicar</strong><p>Rascunhos incompletos podem ser salvos normalmente.</p></div>
      <ul>${errors.slice(0, 8).map(error => `<li>${escapeHtml(error.message)}</li>`).join('')}${errors.length > 8 ? `<li>Mais ${errors.length - 8} pendências.</li>` : ''}</ul>
    </section>`;
  }

  function editorDetailsTemplate(course) {
    return `<div class="ba-form-layout">
      <section class="ba-form-section">
        <div class="ba-section-heading"><span class="ba-eyebrow">Apresentação</span><h2>Informações do curso</h2><p>Esses dados aparecem no catálogo e na página de inscrição.</p></div>
        <div class="ba-form-grid">
          ${field('Nome do curso', 'title', course.title, { required: true, span: 2 })}
          ${field('Subtítulo', 'subtitle', course.subtitle, { span: 2, placeholder: 'Uma frase curta para apresentar a formação' })}
          ${textareaField('Descrição', 'description', course.description, { required: true, span: 2, rows: 6 })}
          ${field('Categoria', 'category', course.category, { required: true, list: 'ba-category-suggestions', placeholder: 'Ex.: Liderança' })}
          <datalist id="ba-category-suggestions"><option value="Liderança"><option value="Discipulado"><option value="Família"><option value="Teologia"><option value="Ministério"></datalist>
          ${selectField('Nível', 'level', course.level, LEVELS.map(value => ({ value, label: value })), { required: true })}
          ${field('Duração', 'duration', course.duration, { required: true, placeholder: 'Ex.: 6 lições ou 8 horas' })}
          ${field('Identificador do curso', 'id', course.id, { readonly: true, help: 'Gerado uma única vez. A ordem dos módulos e lições não altera seus identificadores.' })}
        </div>
      </section>
      <aside class="ba-form-section ba-cover-section">
        <div class="ba-section-heading"><span class="ba-eyebrow">Imagem</span><h2>Capa do curso</h2></div>
        <div class="ba-cover-preview" ${safeUrl(course.coverImage) ? `style="background-image:url('${escapeAttr(safeCssUrl(course.coverImage))}')"` : ''}>${safeUrl(course.coverImage) ? '' : `<span>${escapeHtml(course.title.slice(0, 2).toUpperCase())}</span>`}</div>
        ${field('Endereço da imagem', 'coverImage', course.coverImage, { type: 'url', placeholder: 'https://…' })}
        <label class="ba-upload-button"><span>Importar imagem</span><input type="file" accept="image/*" data-upload-target="cover"></label>
        ${mediaSelect('Usar imagem da biblioteca', 'cover', 'image', course.coverMediaId)}
        <label class="ba-check"><input type="checkbox" data-course-field="featured" ${course.featured ? 'checked' : ''}><span>Destacar este curso no catálogo</span></label>
      </aside>
    </div>`;
  }

  function editorSettingsTemplate(course) {
    return `<div class="ba-settings-grid">
      <section class="ba-form-section">
        <div class="ba-section-heading"><span class="ba-eyebrow">Comercial</span><h2>Preço e condições</h2><p>Configure o valor exibido e o modo de inscrição do curso.</p></div>
        <div class="ba-form-grid">
          ${field('Preço integral (R$)', 'pricing.fullPrice', course.pricing.fullPrice, { type: 'number', min: 0, step: '0.01', required: true })}
          ${selectField('Moeda', 'pricing.currency', course.pricing.currency, [{ value: 'BRL', label: 'Real brasileiro (BRL)' }])}
          ${selectField('Modo de cobrança', 'pricing.mode', course.pricing.mode, [
            { value: 'production', label: 'Cobrança ativa' },
            { value: 'free', label: 'Curso gratuito' },
            { value: 'demo', label: 'Demonstração sem cobrança' },
          ])}
        </div>
        <div class="ba-price-preview"><span>Valor exibido no catálogo</span><strong>${money(course.pricing.fullPrice)}</strong><small>A integração de cobrança real será ativada somente com o provedor oficial.</small></div>
      </section>
      <section class="ba-form-section">
        <div class="ba-section-heading"><span class="ba-eyebrow">Disponibilidade</span><h2>Situação do curso</h2></div>
        <div class="ba-status-options">
          ${statusRadio('draft', course.status, 'Rascunho', 'Visível apenas na administração; pode ficar incompleto.')}
          ${statusRadio('published', course.status, 'Publicado', 'Disponível no catálogo após passar pela verificação.')}
          ${statusRadio('archived', course.status, 'Arquivado', 'Retirado do catálogo sem apagar o conteúdo.')}
        </div>
        <div class="ba-readiness-box ${readiness(course).ready ? 'is-ready' : ''}">
          <strong>${readiness(course).ready ? '✓ Curso pronto para publicação' : `${readiness(course).errors.length} pendência${readiness(course).errors.length > 1 ? 's' : ''}`}</strong>
          <p>${readiness(course).ready ? 'Apostilas, vídeos e testes estão configurados.' : 'Use o botão Verificar para consultar todos os itens.'}</p>
        </div>
      </section>
    </div>`;
  }

  function statusRadio(value, selected, title, description) {
    return `<label class="ba-status-option ${value === selected ? 'is-selected' : ''}"><input type="radio" name="ba-course-status" data-course-field="status" value="${value}" ${value === selected ? 'checked' : ''}><span>${statusBadge(value)}<strong>${escapeHtml(title)}</strong><small>${escapeHtml(description)}</small></span></label>`;
  }

  function editorContentTemplate(course) {
    if (!course.modules.length) {
      return `${emptyState('Nenhum módulo adicionado', 'Comece criando o primeiro módulo do curso.')}<div class="ba-centered-action"><button class="ba-button ba-button--primary" data-action="add-module" type="button">Adicionar módulo</button></div>`;
    }
    state.selectedModule = Math.min(state.selectedModule, course.modules.length - 1);
    const module = course.modules[state.selectedModule];
    state.selectedLesson = Math.min(state.selectedLesson, Math.max(0, module.lessons.length - 1));
    const lesson = module.lessons[state.selectedLesson];
    return `<div class="ba-builder">
      <aside class="ba-builder-nav">
        <div class="ba-builder-nav__header"><div><span class="ba-eyebrow">Estrutura</span><h2>Módulos e lições</h2></div><button class="ba-icon-button" type="button" data-action="add-module" aria-label="Adicionar módulo">+</button></div>
        <div class="ba-module-list">${course.modules.map((item, moduleIndex) => moduleNavItem(item, moduleIndex)).join('')}</div>
      </aside>
      <section class="ba-builder-editor">
        ${moduleEditor(module, state.selectedModule)}
        ${lesson ? lessonEditor(lesson, state.selectedModule, state.selectedLesson) : `<div class="ba-inline-empty"><p>Este módulo ainda não tem lições.</p><button type="button" class="ba-button ba-button--primary" data-action="add-lesson">Adicionar lição</button></div>`}
      </section>
    </div>`;
  }

  function moduleNavItem(module, moduleIndex) {
    const selected = moduleIndex === state.selectedModule;
    return `<div class="ba-module-nav ${selected ? 'is-selected' : ''}">
      <button type="button" class="ba-module-nav__title" data-action="select-module" data-index="${moduleIndex}" aria-current="${selected ? 'true' : 'false'}"><span>${String(moduleIndex + 1).padStart(2, '0')}</span><strong>${escapeHtml(module.title)}</strong></button>
      ${selected ? `<div class="ba-lesson-nav">${module.lessons.map((lesson, lessonIndex) => `<button type="button" class="${lessonIndex === state.selectedLesson ? 'is-selected' : ''}" data-action="select-lesson" data-index="${lessonIndex}"><span>${lessonIndex + 1}</span>${escapeHtml(lesson.title)}</button>`).join('')}</div>` : ''}
    </div>`;
  }

  function moduleEditor(module, moduleIndex) {
    return `<section class="ba-module-editor">
      <div class="ba-builder-heading">
        <div><span class="ba-eyebrow">Módulo ${moduleIndex + 1}</span><h2>${escapeHtml(module.title)}</h2></div>
        <div class="ba-order-actions" aria-label="Organizar módulo">
          <button type="button" class="ba-icon-button" data-action="move-module-up" ${moduleIndex === 0 ? 'disabled' : ''} aria-label="Mover módulo para cima">↑</button>
          <button type="button" class="ba-icon-button" data-action="move-module-down" ${moduleIndex === state.editorCourse.modules.length - 1 ? 'disabled' : ''} aria-label="Mover módulo para baixo">↓</button>
          <button type="button" class="ba-icon-button ba-icon-button--danger" data-action="delete-module" aria-label="Excluir módulo">Excluir</button>
        </div>
      </div>
      <div class="ba-form-grid">
        ${field('Título do módulo', `modules.${moduleIndex}.title`, module.title, { required: true })}
        ${textareaField('Descrição do módulo', `modules.${moduleIndex}.description`, module.description, { rows: 2 })}
      </div>
      <button type="button" class="ba-button ba-button--outline ba-button--small" data-action="add-lesson">+ Adicionar lição</button>
    </section>`;
  }

  function lessonEditor(lesson, moduleIndex, lessonIndex) {
    const prefix = `modules.${moduleIndex}.lessons.${lessonIndex}`;
    const normalized = normalizeVideoUrl(lesson.videoUrl, lesson.videoProvider);
    return `<section class="ba-lesson-editor">
      <div class="ba-builder-heading">
        <div><span class="ba-eyebrow">Lição ${lessonIndex + 1}</span><h2>${escapeHtml(lesson.title)}</h2></div>
        <div class="ba-order-actions" aria-label="Organizar lição">
          <button type="button" class="ba-icon-button" data-action="move-lesson-up" ${lessonIndex === 0 ? 'disabled' : ''} aria-label="Mover lição para cima">↑</button>
          <button type="button" class="ba-icon-button" data-action="move-lesson-down" ${lessonIndex === state.editorCourse.modules[moduleIndex].lessons.length - 1 ? 'disabled' : ''} aria-label="Mover lição para baixo">↓</button>
          <button type="button" class="ba-icon-button ba-icon-button--danger" data-action="delete-lesson" aria-label="Excluir lição">Excluir</button>
        </div>
      </div>
      <div class="ba-form-grid">
        ${field('Título da lição', `${prefix}.title`, lesson.title, { required: true, span: 2 })}
        ${textareaField('Descrição', `${prefix}.description`, lesson.description, { required: true, span: 2, rows: 3 })}
      </div>
      <div class="ba-content-block">
        <div class="ba-content-block__heading"><span class="ba-step-number">01</span><div><h3>Apostila</h3><p>Envie o PDF que o aluno deverá ler antes do vídeo.</p></div></div>
        <div class="ba-form-grid">
          ${field('Título da apostila', `${prefix}.pdfTitle`, lesson.pdfTitle, { placeholder: `Apostila — ${lesson.title}` })}
          ${field('Endereço do PDF', `${prefix}.pdfUrl`, lesson.pdfUrl, { type: 'url', required: true, placeholder: 'https://… ou arquivo importado' })}
        </div>
        <div class="ba-attach-row">
          <label class="ba-upload-button"><span>Importar PDF</span><input type="file" accept="application/pdf" data-upload-target="pdf"></label>
          ${mediaSelect('Escolher da biblioteca', 'pdf', 'pdf', lesson.pdfMediaId)}
          ${safeUrl(lesson.pdfUrl) ? `<a class="ba-link-button" href="${escapeAttr(safeUrl(lesson.pdfUrl))}" target="_blank" rel="noopener">Visualizar apostila</a>` : ''}
        </div>
      </div>
      <div class="ba-content-block">
        <div class="ba-content-block__heading"><span class="ba-step-number">02</span><div><h3>Vídeo</h3><p>Use YouTube, Vimeo, endereço direto ou envie um arquivo.</p></div></div>
        <div class="ba-form-grid">
          ${selectField('Origem do vídeo', `${prefix}.videoProvider`, lesson.videoProvider, Object.entries(VIDEO_PROVIDERS).map(([value, label]) => ({ value, label })), { dataAttr: 'data-video-provider' })}
          ${field('Título do vídeo', `${prefix}.videoTitle`, lesson.videoTitle, { placeholder: `Aula — ${lesson.title}` })}
          <label class="ba-field ba-field--span-2"><span>Link ou endereço do vídeo <b aria-hidden="true">*</b></span><div class="ba-inline-input"><input type="url" data-video-url="${escapeAttr(prefix)}" value="${escapeAttr(lesson.videoUrl)}" placeholder="Cole o link do YouTube, Vimeo ou arquivo"><button type="button" class="ba-button ba-button--small ba-button--outline" data-action="normalize-video">Reconhecer link</button></div><small>${normalized.embedId ? `${VIDEO_PROVIDERS[normalized.provider]} reconhecido · código ${escapeHtml(normalized.embedId)}` : 'Links do YouTube e Vimeo são convertidos automaticamente para o formato do player.'}</small></label>
        </div>
        <div class="ba-attach-row">
          <label class="ba-upload-button"><span>Importar vídeo</span><input type="file" accept="video/*" data-upload-target="video"></label>
          ${mediaSelect('Escolher vídeo da biblioteca', 'video', 'video', lesson.videoMediaId)}
        </div>
      </div>
      <div class="ba-content-block ba-quiz-builder">
        <div class="ba-content-block__heading"><span class="ba-step-number">03</span><div><h3>Teste da lição</h3><p>Para publicar, cada lição precisa ter exatamente 5 questões com 4 alternativas.</p></div></div>
        <div class="ba-quiz-settings">
          ${field('Nota mínima (de 1 a 5)', `${prefix}.quizConfig.passingScore`, lesson.quizConfig.passingScore, { type: 'number', min: 1, max: 5 })}
          ${field('Tentativas permitidas', `${prefix}.quizConfig.maxAttempts`, lesson.quizConfig.maxAttempts, { type: 'number', min: 1, max: 20 })}
          <label class="ba-check"><input type="checkbox" data-course-field="${prefix}.quizConfig.shuffleQuestions" ${lesson.quizConfig.shuffleQuestions ? 'checked' : ''}><span>Embaralhar questões</span></label>
          <label class="ba-check"><input type="checkbox" data-course-field="${prefix}.quizConfig.shuffleOptions" ${lesson.quizConfig.shuffleOptions ? 'checked' : ''}><span>Embaralhar alternativas</span></label>
        </div>
        <div class="ba-question-list">${lesson.quiz.map((question, questionIndex) => questionEditor(question, prefix, questionIndex)).join('')}</div>
        <button type="button" class="ba-button ba-button--outline" data-action="add-question">+ Adicionar questão</button>
        <span class="ba-question-count ${lesson.quiz.length === 5 ? 'is-ready' : ''}">${lesson.quiz.length}/5 questões</span>
      </div>
    </section>`;
  }

  function questionEditor(question, lessonPrefix, questionIndex) {
    const prefix = `${lessonPrefix}.quiz.${questionIndex}`;
    return `<fieldset class="ba-question-card">
      <legend><span>Questão ${String(questionIndex + 1).padStart(2, '0')}</span><button type="button" class="ba-link-button ba-link-button--danger" data-action="remove-question" data-question-index="${questionIndex}">Remover</button></legend>
      ${textareaField('Enunciado', `${prefix}.question`, question.question, { required: true, rows: 2, span: 2 })}
      <div class="ba-options" role="radiogroup" aria-label="Alternativas da questão ${questionIndex + 1}">
        ${question.options.map((option, optionIndex) => `<label class="ba-option ${option.id === question.correctOptionId ? 'is-correct' : ''}">
          <input type="radio" name="correct-${escapeAttr(question.id)}" data-correct-option="${escapeAttr(prefix)}" value="${escapeAttr(option.id)}" ${option.id === question.correctOptionId ? 'checked' : ''}>
          <span class="ba-option__letter">${String.fromCharCode(65 + optionIndex)}</span>
          <span class="ba-sr-only">Marcar como correta</span>
          <input type="text" data-course-field="${escapeAttr(prefix)}.options.${optionIndex}.text" value="${escapeAttr(option.text)}" placeholder="Alternativa ${String.fromCharCode(65 + optionIndex)}" aria-label="Texto da alternativa ${String.fromCharCode(65 + optionIndex)}">
        </label>`).join('')}
      </div>
      ${textareaField('Explicação após responder (opcional)', `${prefix}.explanation`, question.explanation, { rows: 2, span: 2 })}
    </fieldset>`;
  }

  function mediaTemplate() {
    const term = state.mediaSearch.trim().toLocaleLowerCase('pt-BR');
    const files = state.media.filter(item => {
      const matchesSearch = !term || `${item.name} ${item.filename}`.toLocaleLowerCase('pt-BR').includes(term);
      const matchesKind = state.mediaKind === 'all' || item.kind === state.mediaKind;
      return matchesSearch && matchesKind;
    });
    return `
      ${pageHeader('Arquivos', 'Biblioteca de mídia', 'Centralize apostilas, imagens e vídeos usados nos cursos.', '<label class="ba-button ba-button--primary ba-file-button"><span>Importar arquivos</span><input type="file" multiple accept="application/pdf,image/*,video/*" data-upload-target="library"></label>')}
      <section class="ba-toolbar" aria-label="Filtros de mídia">
        <label class="ba-search"><span class="ba-sr-only">Buscar arquivos</span><input type="search" data-filter="media-search" value="${escapeAttr(state.mediaSearch)}" placeholder="Buscar arquivos…"><i aria-hidden="true">⌕</i></label>
        <label><span class="ba-sr-only">Tipo de arquivo</span><select data-filter="media-kind">
          ${selectOption('all', state.mediaKind, 'Todos os tipos')}${selectOption('pdf', state.mediaKind, 'Apostilas PDF')}${selectOption('video', state.mediaKind, 'Vídeos')}${selectOption('image', state.mediaKind, 'Imagens')}${selectOption('document', state.mediaKind, 'Outros arquivos')}
        </select></label>
        <span class="ba-result-count">${files.length} arquivo${files.length === 1 ? '' : 's'}</span>
      </section>
      ${files.length ? `<div class="ba-media-grid">${files.map(mediaCard).join('')}</div>` : emptyState('Biblioteca vazia', 'Importe uma apostila, imagem ou vídeo para começar.')}
      ${state.mode === 'local' ? '<p class="ba-footnote">No modo local, arquivos são limitados a 4 MB. O servidor conectado aceita mídias maiores conforme a configuração de armazenamento.</p>' : ''}`;
  }

  function mediaCard(item) {
    const label = { pdf: 'PDF', video: 'Vídeo', image: 'Imagem', document: 'Arquivo' }[item.kind] || 'Arquivo';
    return `<article class="ba-media-card">
      <div class="ba-media-card__preview ${item.kind === 'image' ? 'is-image' : ''}" ${item.kind === 'image' && safeUrl(item.url) ? `style="background-image:url('${escapeAttr(safeCssUrl(item.url))}')"` : ''}>
        ${item.kind === 'image' && safeUrl(item.url) ? '' : `<span>${escapeHtml(label.slice(0, 3).toUpperCase())}</span>`}
      </div>
      <div class="ba-media-card__body"><strong title="${escapeAttr(item.name)}">${escapeHtml(item.name)}</strong><span>${escapeHtml(label)} · ${formatBytes(item.size)}</span><small>${formatDate(item.createdAt)}</small></div>
      <div class="ba-media-card__actions">${safeUrl(item.url) ? `<a href="${escapeAttr(safeUrl(item.url))}" target="_blank" rel="noopener" class="ba-link-button">Abrir</a>` : ''}<button type="button" class="ba-link-button ba-link-button--danger" data-action="delete-media" data-media-id="${escapeAttr(item.id)}">Excluir</button></div>
    </article>`;
  }

  function getAdminStudents() {
    const source = window.BetaAdminStudents;
    if (Array.isArray(source)) return clone(source);
    if (Array.isArray(source?.students)) return clone(source.students);
    if (typeof source?.list === 'function') {
      try {
        const listed = source.list();
        if (Array.isArray(listed)) return clone(listed);
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  function studentsTemplate() {
    const students = state.students;
    const usesDemoStudents = state.studentsSource === 'demo';
    if (!Array.isArray(students)) {
      return `${pageHeader('Acompanhamento pastoral', 'Alunos', 'Consulte a evolução dos participantes em cada formação.')}
        <section class="ba-panel">${emptyState('Dados de alunos indisponíveis', 'Não foi possível carregar o acompanhamento neste momento. Atualize o painel para tentar novamente.')}</section>`;
    }
    const term = state.studentSearch.trim().toLocaleLowerCase('pt-BR');
    const filtered = students.filter(student => {
      const matchesSearch = !term || `${student.name} ${student.email}`.toLocaleLowerCase('pt-BR').includes(term);
      const matchesCourse = state.studentCourse === 'all' || Boolean(student.progress?.[state.studentCourse]);
      return matchesSearch && matchesCourse;
    });
    return `${pageHeader('Acompanhamento pastoral', 'Alunos', 'Consulte a evolução dos participantes em cada formação.')}
      ${usesDemoStudents ? '<div class="ba-banner ba-banner--warning" role="status"><strong>Dados demonstrativos.</strong> Estes nomes e progressos servem apenas para validar a aparência do painel e não representam a base real da igreja.</div>' : ''}
      <section class="ba-stat-grid ba-stat-grid--three" aria-label="Resumo dos alunos">
        ${statCard('Alunos', students.length, 'Participantes cadastrados')}
        ${statCard('Em atividade', students.filter(student => bestStudentProgress(student).percentage > 0 && bestStudentProgress(student).percentage < 100).length, 'Com curso em andamento')}
        ${statCard('Conclusões', students.filter(student => bestStudentProgress(student).percentage === 100).length, 'Formações concluídas')}
      </section>
      <section class="ba-table-panel">
        <div class="ba-toolbar">
          <label class="ba-search"><span class="ba-sr-only">Buscar alunos</span><input type="search" data-filter="student-search" value="${escapeAttr(state.studentSearch)}" placeholder="Buscar por nome ou e-mail…"><i aria-hidden="true">⌕</i></label>
          <label><span class="ba-sr-only">Filtrar por curso</span><select data-filter="student-course">${selectOption('all', state.studentCourse, 'Todos os cursos')}${state.courses.map(course => selectOption(course.id, state.studentCourse, course.title)).join('')}</select></label>
          <span class="ba-result-count">${filtered.length} aluno${filtered.length === 1 ? '' : 's'}</span>
        </div>
        <div class="ba-table-scroll"><table class="ba-table"><caption class="ba-sr-only">Progresso dos alunos</caption><thead><tr><th scope="col">Aluno</th><th scope="col">Curso</th><th scope="col">Progresso</th><th scope="col">Situação</th><th scope="col">Último acesso</th></tr></thead><tbody>${filtered.map(studentRow).join('')}</tbody></table></div>
      </section>`;
  }

  function bestStudentProgress(student) {
    const entries = Object.entries(student.progress || {});
    if (!entries.length) return { courseId: null, percentage: 0, completedLessons: 0 };
    if (state.studentCourse !== 'all' && student.progress?.[state.studentCourse]) {
      return { courseId: state.studentCourse, ...student.progress[state.studentCourse] };
    }
    const [courseId, progress] = entries.sort((a, b) => (b[1]?.percentage || 0) - (a[1]?.percentage || 0))[0];
    return { courseId, ...progress };
  }

  function studentRow(student) {
    const progress = bestStudentProgress(student);
    const course = state.courses.find(item => item.id === progress.courseId);
    const percentage = Number(progress.percentage) || 0;
    const situation = percentage === 100 ? 'Concluído' : percentage > 0 ? 'Em andamento' : 'Ainda não iniciou';
    return `<tr><td><strong>${escapeHtml(student.name || 'Sem nome')}</strong><small>${escapeHtml(student.email || '')}</small></td><td>${escapeHtml(course?.title || progress.courseId || '—')}</td><td><div class="ba-progress"><span style="width:${Math.max(0, Math.min(100, percentage))}%"></span></div><small>${percentage}%${progress.completedLessons != null ? ` · ${progress.completedLessons} lições` : ''}</small></td><td><span class="ba-student-state">${situation}</span></td><td>${formatDate(student.lastAccess)}</td></tr>`;
  }

  function backupTemplate() {
    return `${pageHeader('Proteção de dados', 'Backup e configurações', 'Exporte uma cópia dos cursos e restaure o conteúdo quando necessário.')}
      <div class="ba-settings-grid">
        <section class="ba-form-section">
          <div class="ba-section-heading"><span class="ba-eyebrow">Exportar</span><h2>Baixar backup</h2><p>Gere um arquivo JSON com cursos, módulos, lições, questões e referências de mídia.</p></div>
          <div class="ba-backup-illustration"><span>{ }</span><div><strong>${state.courses.length} cursos</strong><small>${state.media.length} arquivos registrados</small></div></div>
          <button type="button" class="ba-button ba-button--primary" data-action="export-backup">Baixar backup JSON</button>
        </section>
        <section class="ba-form-section">
          <div class="ba-section-heading"><span class="ba-eyebrow">Restaurar</span><h2>Importar backup</h2><p>A importação substitui a lista de cursos. Uma confirmação será solicitada antes de continuar.</p></div>
          <label class="ba-dropzone"><input type="file" accept="application/json,.json" data-upload-target="backup"><span>Selecionar arquivo de backup</span><small>Formato aceito: .json</small></label>
          <div class="ba-danger-note"><strong>Atenção</strong><p>Faça uma exportação antes de restaurar outro arquivo.</p></div>
        </section>
      </div>
      <section class="ba-panel ba-system-info"><div><span class="ba-eyebrow">Ambiente</span><h2>Informações da plataforma</h2></div><dl><div><dt>Fonte dos dados</dt><dd>${state.mode === 'api' ? 'Servidor Beta Cursos' : 'Navegador local — desenvolvimento'}</dd></div><div><dt>Versão do painel</dt><dd>1.0</dd></div><div><dt>Última atualização</dt><dd>${formatDate(new Date())}</dd></div></dl></section>`;
  }

  function field(label, path, value, options) {
    const config = options || {};
    const id = `ba-field-${slugify(path)}-${Math.abs(hash(path))}`;
    const attrs = [
      `id="${id}"`,
      `type="${config.type || 'text'}"`,
      `data-course-field="${escapeAttr(path)}"`,
      `value="${escapeAttr(value)}"`,
      config.required ? 'required' : '',
      config.min != null ? `min="${escapeAttr(config.min)}"` : '',
      config.max != null ? `max="${escapeAttr(config.max)}"` : '',
      config.step != null ? `step="${escapeAttr(config.step)}"` : '',
      config.placeholder ? `placeholder="${escapeAttr(config.placeholder)}"` : '',
      config.list ? `list="${escapeAttr(config.list)}"` : '',
      config.readonly ? 'readonly aria-readonly="true"' : '',
      config.dataAttr || '',
    ].filter(Boolean).join(' ');
    return `<label class="ba-field ${config.span === 2 ? 'ba-field--span-2' : ''}" for="${id}"><span>${escapeHtml(label)}${config.required ? ' <b aria-hidden="true">*</b>' : ''}</span><input ${attrs}>${config.help ? `<small>${escapeHtml(config.help)}</small>` : ''}</label>`;
  }

  function textareaField(label, path, value, options) {
    const config = options || {};
    const id = `ba-field-${slugify(path)}-${Math.abs(hash(path))}`;
    return `<label class="ba-field ${config.span === 2 ? 'ba-field--span-2' : ''}" for="${id}"><span>${escapeHtml(label)}${config.required ? ' <b aria-hidden="true">*</b>' : ''}</span><textarea id="${id}" data-course-field="${escapeAttr(path)}" rows="${config.rows || 4}" ${config.required ? 'required' : ''}>${escapeHtml(value)}</textarea>${config.help ? `<small>${escapeHtml(config.help)}</small>` : ''}</label>`;
  }

  function selectField(label, path, value, options, config) {
    const id = `ba-field-${slugify(path)}-${Math.abs(hash(path))}`;
    return `<label class="ba-field" for="${id}"><span>${escapeHtml(label)}${config?.required ? ' <b aria-hidden="true">*</b>' : ''}</span><select id="${id}" data-course-field="${escapeAttr(path)}" ${config?.dataAttr || ''}>${options.map(option => selectOption(option.value, value, option.label)).join('')}</select></label>`;
  }

  function selectOption(value, selected, label) {
    return `<option value="${escapeAttr(value)}" ${String(value) === String(selected) ? 'selected' : ''}>${escapeHtml(label)}</option>`;
  }

  function mediaSelect(label, target, kind, selectedId) {
    const files = state.media.filter(item => item.kind === kind);
    return `<label class="ba-compact-select"><span class="ba-sr-only">${escapeHtml(label)}</span><select data-attach-media="${escapeAttr(target)}"><option value="">${escapeHtml(label)}</option>${files.map(item => `<option value="${escapeAttr(item.id)}" ${item.id === selectedId ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}</select></label>`;
  }

  function emptyState(title, description) {
    return `<div class="ba-empty"><span aria-hidden="true">B/</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(description)}</p></div>`;
  }

  function hash(value) {
    return String(value).split('').reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0);
  }

  function updateDirtyIndicator() {
    const indicator = state.root?.querySelector('[data-ba-save-state]');
    if (!indicator) return;
    indicator.textContent = state.editorDirty ? 'Alterações não salvas' : 'Tudo salvo';
    indicator.classList.toggle('is-dirty', state.editorDirty);
  }

  function markDirty() {
    state.editorDirty = true;
    state.validationErrors = [];
    updateDirtyIndicator();
  }

  function toast(message, type) {
    const region = state.root?.querySelector('[data-ba-toasts]');
    if (!region) return;
    const item = document.createElement('div');
    item.className = `ba-toast ba-toast--${type || 'info'}`;
    item.textContent = message;
    region.appendChild(item);
    requestAnimationFrame(() => item.classList.add('is-visible'));
    setTimeout(() => {
      item.classList.remove('is-visible');
      setTimeout(() => item.remove(), 250);
    }, 4200);
  }

  function setBusy(busy) {
    state.busy = Boolean(busy);
    state.root?.querySelector('[data-ba-app]')?.classList.toggle('is-busy', state.busy);
  }

  async function confirmDialog(options) {
    const layer = state.root.querySelector('[data-ba-modal]');
    state.lastFocus = document.activeElement;
    layer.innerHTML = `<div class="ba-modal-backdrop" data-action="cancel-modal"></div><section class="ba-modal" role="alertdialog" aria-modal="true" aria-labelledby="ba-modal-title" aria-describedby="ba-modal-description">
      <span class="ba-eyebrow">Confirmação</span><h2 id="ba-modal-title">${escapeHtml(options.title)}</h2><p id="ba-modal-description">${escapeHtml(options.message)}</p>
      <div class="ba-modal__actions"><button type="button" class="ba-button ba-button--ghost" data-action="cancel-modal">Cancelar</button><button type="button" class="ba-button ${options.danger ? 'ba-button--danger' : 'ba-button--primary'}" data-action="confirm-modal">${escapeHtml(options.confirmLabel || 'Confirmar')}</button></div>
    </section>`;
    layer.classList.add('is-open');
    document.body.classList.add('ba-modal-open');
    const confirm = layer.querySelector('[data-action="confirm-modal"]');
    confirm.focus();
    return new Promise(resolve => {
      function finish(result) {
        layer.removeEventListener('click', onClick);
        layer.removeEventListener('keydown', onKey);
        layer.classList.remove('is-open');
        layer.innerHTML = '';
        document.body.classList.remove('ba-modal-open');
        state.lastFocus?.focus?.();
        resolve(result);
      }
      function onClick(event) {
        if (event.target.closest('[data-action="confirm-modal"]')) finish(true);
        if (event.target.closest('[data-action="cancel-modal"]')) finish(false);
      }
      function onKey(event) {
        if (event.key === 'Escape') finish(false);
        if (event.key === 'Tab') {
          const focusable = [...layer.querySelectorAll('button:not([disabled])')];
          const first = focusable[0];
          const last = focusable.at(-1);
          if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
        }
      }
      layer.addEventListener('click', onClick);
      layer.addEventListener('keydown', onKey);
    });
  }

  async function openView(view) {
    if (state.view === 'editor' && state.editorDirty && view !== 'editor') {
      const discard = await confirmDialog({
        title: 'Descartar alterações?',
        message: 'As mudanças ainda não salvas neste curso serão perdidas.',
        confirmLabel: 'Descartar',
        danger: true,
      });
      if (!discard) return;
    }
    state.view = view;
    state.editorCourse = view === 'editor' ? state.editorCourse : null;
    state.editorDirty = false;
    state.mobileOpen = false;
    state.root.querySelector('[data-ba-app]').classList.remove('is-menu-open');
    render();
    state.root.querySelector('#ba-main')?.focus();
  }

  async function refreshCourses() {
    state.courses = await state.adapter.listCourses();
  }

  async function editCourse(id) {
    setBusy(true);
    try {
      state.editorCourse = await state.adapter.getCourse(id);
      state.editorOriginalId = id;
      state.editorIsNew = false;
      state.editorDirty = false;
      state.editorTab = 'details';
      state.selectedModule = 0;
      state.selectedLesson = 0;
      state.validationErrors = [];
      state.view = 'editor';
      render();
    } catch (error) {
      toast(error.message || 'Não foi possível abrir o curso.', 'error');
    } finally {
      setBusy(false);
    }
  }

  function newCourse() {
    state.editorCourse = createBlankCourse();
    state.editorOriginalId = null;
    state.editorIsNew = true;
    state.editorDirty = true;
    state.editorTab = 'details';
    state.selectedModule = 0;
    state.selectedLesson = 0;
    state.validationErrors = [];
    state.view = 'editor';
    render();
    state.root.querySelector('[data-course-field="title"]')?.select();
  }

  async function saveCourse(options) {
    const config = options || {};
    if (!state.editorCourse) return;
    const course = normalizeCourse(state.editorCourse);
    if (config.publish) course.status = 'published';
    if (config.unpublish) course.status = 'draft';
    if (course.status === 'published') {
      const errors = validateCourse(course);
      if (errors.length) {
        state.editorCourse = course;
        state.validationErrors = errors;
        state.editorTab = errors.some(error => error.path.startsWith('modules')) ? 'content' : 'details';
        render();
        requestAnimationFrame(() => state.root.querySelector('[data-ba-validation]')?.focus());
        toast('O curso precisa de ajustes antes de ser publicado.', 'error');
        return;
      }
    }
    setBusy(true);
    try {
      course.updatedAt = new Date().toISOString();
      const saved = state.editorIsNew
        ? await state.adapter.createCourse(course)
        : await state.adapter.updateCourse(state.editorOriginalId, course);
      state.editorCourse = normalizeCourse(saved || course);
      state.editorOriginalId = state.editorCourse.id;
      state.editorIsNew = false;
      state.editorDirty = false;
      state.validationErrors = [];
      await refreshCourses();
      dispatchCoursesChanged();
      render();
      toast(config.publish ? 'Curso publicado com sucesso.' : config.unpublish ? 'Curso voltou para rascunho.' : 'Alterações salvas.', 'success');
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        toast('Conflito de edição: outra pessoa salvou este curso. Suas alterações não foram sobrescritas; recarregue o curso antes de tentar novamente.', 'error');
      } else {
        toast(error.message || 'Não foi possível salvar o curso.', 'error');
      }
    } finally {
      setBusy(false);
    }
  }

  async function duplicateCourse(id) {
    const source = state.courses.find(course => course.id === id);
    if (!source) return;
    const copy = renewNestedIds(source);
    copy.title = `${source.title} — cópia`;
    copy.status = 'draft';
    copy.createdAt = new Date().toISOString();
    copy.updatedAt = copy.createdAt;
    setBusy(true);
    try {
      const created = await state.adapter.createCourse(copy);
      await refreshCourses();
      dispatchCoursesChanged();
      render();
      toast('Cópia criada como rascunho.', 'success');
      await editCourse(created.id);
    } catch (error) {
      toast(error.message || 'Não foi possível duplicar o curso.', 'error');
    } finally { setBusy(false); }
  }

  async function deleteCourse(id) {
    const course = state.courses.find(item => item.id === id);
    if (!course) return;
    if (course.status !== 'draft') {
      toast('Somente rascunhos podem ser excluídos. Arquive cursos já publicados.', 'error');
      return;
    }
    const confirmed = await confirmDialog({
      title: `Excluir “${course.title}”?`,
      message: 'Esta ação remove módulos, lições e questões. Faça um backup antes se precisar manter uma cópia.',
      confirmLabel: 'Excluir curso',
      danger: true,
    });
    if (!confirmed) return;
    setBusy(true);
    try {
      await state.adapter.deleteCourse(id);
      await refreshCourses();
      dispatchCoursesChanged();
      render();
      toast('Curso excluído.', 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível excluir o curso.', 'error');
    } finally { setBusy(false); }
  }

  async function changeCourseStatus(id, status) {
    const source = state.courses.find(course => course.id === id);
    if (!source) return;
    if (status === 'published') {
      await editCourse(id);
      await saveCourse({ publish: true });
      return;
    }
    if (status === 'archived') {
      const confirmed = await confirmDialog({
        title: 'Arquivar este curso?',
        message: 'Ele deixará de aparecer no catálogo, mas todo o conteúdo será preservado.',
        confirmLabel: 'Arquivar',
      });
      if (!confirmed) return;
    }
    setBusy(true);
    try {
      await state.adapter.updateCourse(id, { ...source, status, updatedAt: new Date().toISOString() });
      await refreshCourses();
      dispatchCoursesChanged();
      render();
      toast(status === 'archived' ? 'Curso arquivado.' : 'Curso restaurado como rascunho.', 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível alterar a situação.', 'error');
    } finally { setBusy(false); }
  }

  function selectedLesson() {
    return state.editorCourse?.modules?.[state.selectedModule]?.lessons?.[state.selectedLesson] || null;
  }

  async function uploadFiles(fileList, target) {
    const files = [...(fileList || [])];
    if (!files.length) return;
    setBusy(true);
    try {
      for (const file of files) {
        if (target === 'pdf' && file.type !== 'application/pdf') throw new ApiError('Selecione um arquivo PDF para a apostila.', 400);
        const expectedKind = target === 'cover' ? 'image' : target === 'pdf' ? 'pdf' : target === 'video' ? 'video' : mediaKindFromType(file.type);
        const media = await state.adapter.uploadMedia(file, expectedKind);
        state.media = [media, ...state.media.filter(item => item.id !== media.id)];
        if (target === 'cover' && state.editorCourse) {
          state.editorCourse.coverImage = media.url;
          state.editorCourse.coverMediaId = media.id;
          markDirty();
        } else if (target === 'pdf' && selectedLesson()) {
          const lesson = selectedLesson();
          lesson.pdfUrl = media.url;
          lesson.pdfMediaId = media.id;
          lesson.pdfTitle ||= file.name.replace(/\.pdf$/i, '');
          markDirty();
        } else if (target === 'video' && selectedLesson()) {
          const lesson = selectedLesson();
          lesson.videoProvider = 'upload';
          lesson.videoUrl = media.url;
          lesson.videoEmbedId = '';
          lesson.videoMediaId = media.id;
          lesson.videoTitle ||= file.name.replace(/\.[^.]+$/, '');
          markDirty();
        }
      }
      render();
      toast(`${files.length} arquivo${files.length > 1 ? 's importados' : ' importado'} com sucesso.`, 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível importar o arquivo.', 'error');
    } finally { setBusy(false); }
  }

  async function deleteMedia(id) {
    const media = state.media.find(item => item.id === id);
    if (!media) return;
    const confirmed = await confirmDialog({
      title: `Excluir “${media.name}”?`,
      message: 'Cursos que usam este arquivo podem ficar sem apostila, vídeo ou imagem.',
      confirmLabel: 'Excluir arquivo',
      danger: true,
    });
    if (!confirmed) return;
    setBusy(true);
    try {
      await state.adapter.deleteMedia(id);
      state.media = state.media.filter(item => item.id !== id);
      render();
      toast('Arquivo excluído da biblioteca.', 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível excluir o arquivo.', 'error');
    } finally { setBusy(false); }
  }

  async function exportBackup() {
    setBusy(true);
    try {
      const data = await state.adapter.exportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `beta-cursos-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      toast('Backup baixado.', 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível gerar o backup.', 'error');
    } finally { setBusy(false); }
  }

  async function importBackup(file) {
    let data;
    try {
      data = normalizeBackup(JSON.parse(await file.text()));
    } catch (error) {
      toast(error.message || 'O arquivo selecionado não é um backup válido.', 'error');
      return;
    }
    const confirmed = await confirmDialog({
      title: 'Restaurar este backup?',
      message: 'A lista atual de cursos será substituída pelo conteúdo do arquivo selecionado.',
      confirmLabel: 'Restaurar backup',
      danger: true,
    });
    if (!confirmed) return;
    setBusy(true);
    try {
      const result = await state.adapter.importData(data);
      await refreshCourses();
      if (Array.isArray(result?.media)) state.media = result.media.map(item => normalizeMedia(item));
      else state.media = await state.adapter.listMedia();
      dispatchCoursesChanged();
      render();
      toast('Backup restaurado com sucesso.', 'success');
    } catch (error) {
      toast(error.message || 'Não foi possível restaurar o backup.', 'error');
    } finally { setBusy(false); }
  }

  function attachSelectedMedia(target, mediaId) {
    const media = state.media.find(item => item.id === mediaId);
    if (!media || !state.editorCourse) return;
    const lesson = selectedLesson();
    if (target === 'cover') {
      state.editorCourse.coverImage = media.url;
      state.editorCourse.coverMediaId = media.id;
    } else if (target === 'pdf' && lesson) {
      lesson.pdfUrl = media.url;
      lesson.pdfMediaId = media.id;
      lesson.pdfTitle ||= media.name.replace(/\.pdf$/i, '');
    } else if (target === 'video' && lesson) {
      lesson.videoProvider = 'upload';
      lesson.videoUrl = media.url;
      lesson.videoEmbedId = '';
      lesson.videoMediaId = media.id;
      lesson.videoTitle ||= media.name.replace(/\.[^.]+$/, '');
    }
    markDirty();
    render();
  }

  function onCourseFieldChange(element) {
    if (!state.editorCourse) return;
    const path = element.dataset.courseField;
    if (!path) return;
    let value;
    if (element.type === 'checkbox') value = element.checked;
    else if (element.type === 'number') value = element.value === '' ? 0 : Number(element.value);
    else value = element.value;
    setPath(state.editorCourse, path, value);
    if (path === 'pricing.discountPercent') {
      state.editorCourse.pricing.memberDiscount = Number(value) / 100;
    }
    if (path === 'title' && state.editorIsNew && state.editorCourse.slug === 'novo-curso') {
      state.editorCourse.slug = slugify(value);
    }
    markDirty();
  }

  async function handleAction(button) {
    const action = button.dataset.action;
    if (!action) return;
    if (action === 'toggle-menu') {
      state.mobileOpen = !state.mobileOpen;
      state.root.querySelector('[data-ba-app]').classList.toggle('is-menu-open', state.mobileOpen);
      button.setAttribute('aria-expanded', String(state.mobileOpen));
    } else if (action === 'close-menu') {
      state.mobileOpen = false;
      state.root.querySelector('[data-ba-app]').classList.remove('is-menu-open');
      state.root.querySelector('[data-action="toggle-menu"]')?.setAttribute('aria-expanded', 'false');
    } else if (action === 'leave-admin') {
      if (state.editorDirty) {
        const discard = await confirmDialog({
          title: 'Sair sem salvar?',
          message: 'As alterações ainda não salvas neste curso serão perdidas.',
          confirmLabel: 'Sair do painel',
          danger: true,
        });
        if (!discard) return;
        state.editorDirty = false;
      }
      if (window.Router?.navigate) window.Router.navigate('landing');
      else window.location.href = '/';
    } else if (action === 'new-course') newCourse();
    else if (action === 'edit-course') await editCourse(button.dataset.courseId);
    else if (action === 'duplicate-course') await duplicateCourse(button.dataset.courseId);
    else if (action === 'delete-course') await deleteCourse(button.dataset.courseId);
    else if (action === 'change-course-status') await changeCourseStatus(button.dataset.courseId, button.dataset.status);
    else if (action === 'toggle-card-menu') {
      const menu = button.nextElementSibling;
      const willOpen = menu.hidden;
      state.root.querySelectorAll('.ba-card-menu').forEach(item => { item.hidden = true; });
      state.root.querySelectorAll('[data-action="toggle-card-menu"]').forEach(item => item.setAttribute('aria-expanded', 'false'));
      menu.hidden = !willOpen;
      button.setAttribute('aria-expanded', String(willOpen));
    } else if (action === 'back-to-courses') await openView('courses');
    else if (action === 'save-course') await saveCourse();
    else if (action === 'publish-course') await saveCourse({ publish: true });
    else if (action === 'unpublish-course') await saveCourse({ unpublish: true });
    else if (action === 'validate-course') {
      state.validationErrors = validateCourse(state.editorCourse);
      render();
      if (state.validationErrors.length) {
        state.root.querySelector('[data-ba-validation]')?.focus();
        toast(`${state.validationErrors.length} pendências encontradas.`, 'error');
      } else toast('Curso pronto para publicação.', 'success');
    } else if (action === 'add-module') {
      state.editorCourse.modules.push(createBlankModule(state.editorCourse.modules.length));
      state.selectedModule = state.editorCourse.modules.length - 1;
      state.selectedLesson = 0;
      markDirty(); render();
    } else if (action === 'select-module') {
      state.selectedModule = Number(button.dataset.index);
      state.selectedLesson = 0;
      render();
    } else if (action === 'select-lesson') {
      state.selectedLesson = Number(button.dataset.index);
      render();
    } else if (action === 'move-module-up' || action === 'move-module-down') {
      const direction = action.endsWith('up') ? -1 : 1;
      if (reorder(state.editorCourse.modules, state.selectedModule, state.selectedModule + direction)) {
        state.selectedModule += direction; markDirty(); render();
      }
    } else if (action === 'delete-module') {
      const module = state.editorCourse.modules[state.selectedModule];
      const confirmed = await confirmDialog({ title: `Excluir “${module.title}”?`, message: 'Todas as lições e questões deste módulo serão removidas.', confirmLabel: 'Excluir módulo', danger: true });
      if (confirmed) {
        state.editorCourse.modules.splice(state.selectedModule, 1);
        state.editorCourse.modules.forEach((item, index) => { item.order = index + 1; });
        state.selectedModule = Math.max(0, state.selectedModule - 1); state.selectedLesson = 0; markDirty(); render();
      }
    } else if (action === 'add-lesson') {
      const lessons = state.editorCourse.modules[state.selectedModule].lessons;
      lessons.push(createBlankLesson(lessons.length)); state.selectedLesson = lessons.length - 1; markDirty(); render();
    } else if (action === 'move-lesson-up' || action === 'move-lesson-down') {
      const lessons = state.editorCourse.modules[state.selectedModule].lessons;
      const direction = action.endsWith('up') ? -1 : 1;
      if (reorder(lessons, state.selectedLesson, state.selectedLesson + direction)) {
        state.selectedLesson += direction; markDirty(); render();
      }
    } else if (action === 'delete-lesson') {
      const lesson = selectedLesson();
      const confirmed = await confirmDialog({ title: `Excluir “${lesson.title}”?`, message: 'A apostila, o vídeo e as questões deixarão de fazer parte deste curso.', confirmLabel: 'Excluir lição', danger: true });
      if (confirmed) {
        const lessons = state.editorCourse.modules[state.selectedModule].lessons;
        lessons.splice(state.selectedLesson, 1); lessons.forEach((item, index) => { item.order = index + 1; });
        state.selectedLesson = Math.max(0, state.selectedLesson - 1); markDirty(); render();
      }
    } else if (action === 'add-question') {
      const lesson = selectedLesson();
      lesson.quiz.push(newQuestion(lesson.quiz.length)); markDirty(); render();
    } else if (action === 'remove-question') {
      selectedLesson().quiz.splice(Number(button.dataset.questionIndex), 1); markDirty(); render();
    } else if (action === 'normalize-video') {
      const lesson = selectedLesson();
      const result = normalizeVideoUrl(lesson.videoUrl, lesson.videoProvider);
      lesson.videoProvider = result.provider;
      lesson.videoUrl = result.url;
      lesson.videoEmbedId = result.embedId;
      if (result.provider !== 'upload') lesson.videoMediaId = null;
      markDirty(); render();
      toast(result.invalid ? 'Não foi possível reconhecer esse link. Verifique o endereço.' : `${VIDEO_PROVIDERS[result.provider]} reconhecido.`, result.invalid ? 'error' : 'success');
    } else if (action === 'delete-media') await deleteMedia(button.dataset.mediaId);
    else if (action === 'export-backup') await exportBackup();
  }

  function bindEvents() {
    const listenerOptions = state.eventController ? { signal: state.eventController.signal } : undefined;
    state.root.addEventListener('click', async event => {
      const viewButton = event.target.closest('[data-view]');
      if (viewButton) { event.preventDefault(); await openView(viewButton.dataset.view); return; }
      const tabButton = event.target.closest('[data-editor-tab]');
      if (tabButton) { state.editorTab = tabButton.dataset.editorTab; render(); return; }
      const actionButton = event.target.closest('[data-action]');
      if (actionButton && !actionButton.closest('[data-ba-modal]')) {
        event.preventDefault();
        await handleAction(actionButton);
      }
    }, listenerOptions);

    state.root.addEventListener('input', event => {
      const element = event.target;
      if (element.matches('[data-course-field]')) onCourseFieldChange(element);
      if (element.matches('[data-video-url]') && selectedLesson()) {
        selectedLesson().videoUrl = element.value; markDirty();
      }
      if (element.matches('[data-filter="course-search"]')) { state.courseSearch = element.value; render(); state.root.querySelector('[data-filter="course-search"]')?.focus(); }
      if (element.matches('[data-filter="media-search"]')) { state.mediaSearch = element.value; render(); state.root.querySelector('[data-filter="media-search"]')?.focus(); }
      if (element.matches('[data-filter="student-search"]')) { state.studentSearch = element.value; render(); state.root.querySelector('[data-filter="student-search"]')?.focus(); }
    }, listenerOptions);

    state.root.addEventListener('change', async event => {
      const element = event.target;
      if (element.matches('[data-course-field]')) {
        onCourseFieldChange(element);
        if (element.matches('[data-video-provider]') || element.name === 'ba-course-status') render();
      }
      if (element.matches('[data-video-url]') && selectedLesson()) {
        const lesson = selectedLesson();
        const result = normalizeVideoUrl(element.value, lesson.videoProvider);
        lesson.videoProvider = result.provider;
        lesson.videoUrl = result.url;
        lesson.videoEmbedId = result.embedId;
        lesson.videoMediaId = null;
        markDirty();
        render();
        if (result.invalid) toast('Não foi possível reconhecer esse link. Verifique o endereço.', 'error');
      }
      if (element.matches('[data-correct-option]')) {
        setPath(state.editorCourse, `${element.dataset.correctOption}.correctOptionId`, element.value);
        markDirty(); render();
      }
      if (element.matches('[data-filter="course-status"]')) { state.courseStatus = element.value; render(); }
      if (element.matches('[data-filter="course-category"]')) { state.courseCategory = element.value; render(); }
      if (element.matches('[data-filter="media-kind"]')) { state.mediaKind = element.value; render(); }
      if (element.matches('[data-filter="student-course"]')) { state.studentCourse = element.value; render(); }
      if (element.matches('[data-attach-media]') && element.value) attachSelectedMedia(element.dataset.attachMedia, element.value);
      if (element.matches('[data-upload-target]') && element.files?.length) {
        if (element.dataset.uploadTarget === 'backup') await importBackup(element.files[0]);
        else await uploadFiles(element.files, element.dataset.uploadTarget);
        element.value = '';
      }
    }, listenerOptions);

    state.root.addEventListener('keydown', event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's' && state.view === 'editor') {
        event.preventDefault();
        saveCourse();
      }
      if (event.key === 'Escape') {
        state.root.querySelectorAll('.ba-card-menu').forEach(menu => { menu.hidden = true; });
        state.root.querySelectorAll('[data-action="toggle-card-menu"]').forEach(button => button.setAttribute('aria-expanded', 'false'));
      }
    }, listenerOptions);

    window.addEventListener('beta:students-changed', async () => {
      if (state.mode === 'local') {
        state.students = await localAdapter.listStudents();
      } else if (state.mode === 'api') {
        try {
          state.students = await remoteAdapter.listStudents();
        } catch (_) {
          return;
        }
      }
      if (state.view === 'students') render();
    }, listenerOptions);
  }

  async function initializeData() {
    let bootstrap;
    try {
      bootstrap = await remoteAdapter.bootstrap();
    } catch (error) {
      if (error instanceof ApiError && [401, 403].includes(error.status)) {
        state.mode = 'denied';
        throw error;
      }
      const serverUnavailable = error instanceof ApiError
        && error.status === 503
        && error.payload?.localFallback === true;
      const filePreview = window.location.protocol === 'file:';
      if ((!serverUnavailable && !filePreview) || window.BetaConfig?.allowLocalFallback === false) throw error;
      state.mode = 'local';
      state.adapter = localAdapter;
      const bootstrap = await localAdapter.bootstrap();
      state.bootstrap = bootstrap;
      state.courses = bootstrap.courses.map(course => normalizeCourse(course));
      state.media = bootstrap.media.map(item => normalizeMedia(item));
      state.students = await localAdapter.listStudents();
      state.studentsSource = window.BetaAdminStudents?.source === 'demo' ? 'demo' : 'local';
      return;
    }

    // Após o bootstrap confirmar o servidor, falhas subsequentes não ativam o
    // modo local: assim nunca há duas fontes de verdade para o mesmo painel.
    state.mode = 'api';
    state.adapter = remoteAdapter;
    state.bootstrap = bootstrap || {};
    [state.courses, state.media, state.students] = await Promise.all([
      remoteAdapter.listCourses(),
      remoteAdapter.listMedia(),
      remoteAdapter.listStudents(),
    ]);
    state.studentsSource = 'api';
    if (state.courses.length === 0) {
      const seeds = getSeedCourses();
      for (const source of seeds) {
        const seed = normalizeCourse(source, { seedPublished: true });
        seed.status = 'published';
        await remoteAdapter.createCourse(seed);
      }
      if (seeds.length) {
        state.importedSeed = true;
        state.courses = await remoteAdapter.listCourses();
        dispatchCoursesChanged();
      }
    }
  }

  async function mount(rootElement) {
    if (!(rootElement instanceof Element)) {
      throw new TypeError('BetaAdmin.mount precisa receber um elemento da página.');
    }
    if (!document.querySelector('link[data-beta-admin-style]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'admin.css';
      link.dataset.betaAdminStyle = '';
      document.head.appendChild(link);
    }
    if (state.beforeUnload) window.removeEventListener('beforeunload', state.beforeUnload);
    state.eventController?.abort();
    state.eventController = new AbortController();
    state.root = rootElement;
    state.root.innerHTML = shellTemplate();
    state.adapter = null;
    state.courses = [];
    state.media = [];
    state.students = [];
    state.studentsSource = 'api';
    state.bootstrap = {};
    state.initError = null;
    state.loading = true;
    state.busy = false;
    state.mode = 'loading';
    state.importedSeed = false;
    state.editorCourse = null;
    state.editorDirty = false;
    state.view = 'overview';
    bindEvents();
    render();
    state.beforeUnload = event => {
      if (!state.editorDirty) return;
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', state.beforeUnload);

    try {
      await initializeData();
      state.loading = false;
      render();
      if (state.importedSeed) toast('Jornada Lidere importada como curso inicial publicado.', 'success');
      if (state.mode === 'local') toast('Painel aberto em modo local de desenvolvimento.', 'info');
    } catch (error) {
      state.loading = false;
      if (state.mode !== 'denied') state.mode = 'error';
      state.initError = error;
      render();
    }
    return window.BetaAdmin;
  }

  window.BetaAdmin = Object.freeze({ mount });
})();
