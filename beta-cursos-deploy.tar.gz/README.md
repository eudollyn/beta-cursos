# Beta Cursos

Plataforma de cursos da Igreja Beta com catálogo público, área do aluno e painel administrativo. Esta versão roda como uma aplicação Node única: o mesmo domínio entrega o site e a API, o que simplifica autenticação, cookies, implantação e manutenção.

## O que está funcional

- cadastro, login, logout e restauração de sessão;
- senhas protegidas com `scrypt` e sessões opacas em cookie `HttpOnly`;
- catálogo persistente e painel para criar, editar, publicar, duplicar, arquivar e excluir cursos;
- criação de módulos, lições, cinco questões por lição, alternativas, gabarito e regras de tentativa;
- envio de PDF, capa e vídeo, além de YouTube, Vimeo e URL HTTPS;
- biblioteca de mídia, exportação e restauração de cursos;
- matrícula de homologação, progresso persistente e continuidade em outro navegador;
- correção de avaliações no servidor, tentativas idempotentes e gabarito removido do catálogo público;
- apostilas e vídeos enviados protegidos por sessão e matrícula ativa;
- painel de alunos com progresso real da base;
- SQLite e arquivos locais para desenvolvimento;
- PostgreSQL e Bucket S3 compatível para Railway;
- migrations idempotentes, healthchecks e logs estruturados.

O curso inicial mantém a contribuição aprovada de **R$ 19,90**, sem desconto automático.

## Executar localmente

Requisitos: Node.js 22 ou superior e pnpm.

```powershell
Copy-Item .env.example .env
pnpm install
pnpm dev
```

Abra `http://127.0.0.1:3000`. O servidor aplica as migrations ao iniciar. Localmente, os dados ficam em `.data/beta-cursos.sqlite` e os arquivos em `.data/media`.

O modo de demonstração vem habilitado somente no ambiente local. O servidor importa o curso-base de forma idempotente na primeira inicialização; depois, entre por **Explorar com uma conta de demonstração** para testar a jornada e a administração.

Para executar apenas a antiga prévia estática, sem backend:

```powershell
pnpm dev:static
```

## Painel administrativo

Depois de entrar com uma conta autorizada, abra **Administração**. Em ambiente hospedado, o proprietário inicial é exclusivamente o e-mail definido em `BOOTSTRAP_OWNER_EMAIL`; um visitante não consegue se tornar administrador enviando cabeçalhos pelo navegador.

Para publicar, cada lição precisa ter:

- uma apostila PDF interna;
- um vídeo enviado ou um link permitido;
- exatamente cinco questões;
- quatro alternativas completas em cada questão;
- uma resposta correta.

O passo a passo para a equipe de conteúdo está em [GUIA-ADMINISTRACAO.md](GUIA-ADMINISTRACAO.md).

## Railway

A homologação inicial pode rodar sem assinatura no plano Free como um único
serviço Node, usando SQLite e filesystem no mesmo volume persistente. Esse modo
é ativado explicitamente com `RAILWAY_FREE_VOLUME_MODE=true`, falha se o volume
não estiver anexado e limita os uploads para proteger os 0,5 GB disponíveis.
No painel do serviço, ative também **Settings > Deploy > Serverless**, mantenha
uma réplica e não use monitor externo contínuo. Ele é adequado para testes
esporádicos, não para manter a operação final da igreja disponível
continuamente.

A arquitetura recomendada para produção possui três serviços no mesmo projeto:

- `Web`: frontend, API e painel em Node.js;
- `Postgres`: cursos, usuários, sessões, matrículas e progresso;
- `Media`: Bucket privado compatível com S3.

O `Dockerfile` e o `railway.json` já estão na raiz. O servidor usa `PORT`, escuta em `0.0.0.0`, executa migrations antes de aceitar tráfego e expõe:

- `GET /health/live`;
- `GET /health/ready`.

O handoff completo para o Gilson/equipe de infraestrutura está em [docs/HOSPEDAGEM-RAILWAY.md](docs/HOSPEDAGEM-RAILWAY.md).

## Variáveis essenciais no Railway

Para a homologação Free com um volume anexado em `/data`, use:

```dotenv
APP_ENV=staging
NODE_ENV=production
HOST=0.0.0.0
APP_ORIGIN=https://DOMINIO-GERADO
ALLOWED_ORIGINS=https://DOMINIO-GERADO
RAILWAY_FREE_VOLUME_MODE=true
SESSION_SECRET=SEGREDO_ALEATORIO_COM_32_OU_MAIS_CARACTERES
SESSION_COOKIE_NAME=__Host-beta_session
SESSION_TTL_DAYS=7
COOKIE_SECURE=true
BOOTSTRAP_OWNER_EMAIL=EMAIL_DO_RESPONSAVEL
REGISTRATION_ENABLED=true
ENABLE_DEMO_LOGIN=false
DEMO_ROLE=student
CHECKOUT_MODE=test
LOG_LEVEL=info
STORAGE_MAX_MB=400
PDF_MAX_MB=15
IMAGE_MAX_MB=5
VIDEO_MAX_MB=25
```

`RAILWAY_VOLUME_MOUNT_PATH` é fornecida automaticamente pelo Railway. Nesse
modo, não defina `DATABASE_URL` nem `LOCAL_STORAGE_PATH`: a aplicação os resolve
dentro do volume e recusa iniciar se houver risco de gravar no disco efêmero.

Na arquitetura definitiva com PostgreSQL e Bucket, use como base
`.env.example`. Em staging/produção são obrigatórios:

- `APP_ORIGIN` e `ALLOWED_ORIGINS` em HTTPS;
- `DATABASE_URL=${{Postgres.DATABASE_URL}}`;
- `SESSION_SECRET` com pelo menos 32 caracteres;
- `BOOTSTRAP_OWNER_EMAIL`;
- `STORAGE_DRIVER=s3`;
- `BUCKET`, `ENDPOINT`, `REGION`, `ACCESS_KEY_ID` e `SECRET_ACCESS_KEY` referenciando o serviço `Media`.

Em staging, `CHECKOUT_MODE=test` cria uma matrícula real na base de homologação, mas não movimenta dinheiro. Em produção, mantenha `CHECKOUT_MODE=disabled` até o Mercado Pago e o webhook oficial estarem implementados e validados.

## Verificação

```powershell
pnpm test
```

O comando gera `dist/`, valida a sintaxe e executa a suíte completa. Há testes de integração para cadastro, sessão, bloqueio de identidade forjada, administração, criação de curso, preço de R$ 19,90, matrícula, proteção de mídia, progresso, correção segura dos testes e listagem de alunos.

Outros comandos:

```powershell
pnpm migrate
pnpm build
pnpm package:s3
```

O pacote S3 continua disponível apenas como alternativa estática/legada. Sozinho, um bucket S3 não executa autenticação, banco, progresso ou painel persistente.

## Dependências externas antes da abertura pública

O backend pode ser homologado integralmente no Railway. Ainda dependem de decisões ou credenciais da igreja:

- Mercado Pago, webhook assinado e regras de estorno/reconciliação;
- CRM ou cadastro oficial para validar o código de membro; os campos compatíveis permanecem reservados no backend, mas o recurso não aparece nas telas nem concede benefícios enquanto essa integração não existir;
- provedor de e-mail e recuperação de senha;
- domínio e acesso ao DNS;
- apostilas, vídeos e questões finais;
- decisão pastoral sobre fases, pré-requisitos e exceções;

Até essas integrações serem concluídas, checkout permanece claramente identificado como teste e nenhuma cobrança real é realizada.
