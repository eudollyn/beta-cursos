import {
  createId,
  createOpaqueToken,
  hashMetadata,
  hashOpaqueToken,
  hashPassword,
  verifyPassword,
} from './auth-crypto.mjs';

const JSON_HEADERS = Object.freeze({
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
});
const AUTH_RATE_BUCKETS = new Map();
const INITIALIZED_DATABASES = new WeakMap();
const ADMIN_ROLES = new Set(['owner', 'admin', 'facilitator']);
const PAYMENT_METHODS = new Set(['pix', 'credit_card', 'boleto']);
const QUIZ_STATUSES = new Set(['locked', 'available', 'failed', 'exhausted', 'passed']);
const CATALOG_ANSWER_FIELDS = new Set([
  'answer',
  'correct',
  'correctAnswer',
  'correctIndex',
  'correctOption',
  'correctOptionId',
  'isCorrect',
]);

class ApplicationError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'ApplicationError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

function json(payload, status = 200, headers) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...JSON_HEADERS, ...(headers || {}) },
  });
}

function empty(status = 204, headers) {
  return new Response(null, { status, headers: headers || {} });
}

function errorResponse(error) {
  if (error instanceof ApplicationError) {
    return json({
      error: {
        code: error.code,
        message: error.message,
        ...(error.details === undefined ? {} : { details: error.details }),
      },
    }, error.status);
  }
  console.error('Beta Cursos application API error', error);
  return json({
    error: {
      code: 'internal_error',
      message: 'Não foi possível concluir a operação.',
    },
  }, 500);
}

function envValue(config, camelName, constantName, fallback) {
  if (config?.[camelName] !== undefined) return config[camelName];
  if (config?.[constantName] !== undefined) return config[constantName];
  return fallback;
}

function enabled(value) {
  return value === true || String(value || '').trim().toLowerCase() === 'true';
}

function positiveInteger(value, fallback, minimum, maximum) {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < minimum || parsed > maximum) return fallback;
  return parsed;
}

function applicationConfig(config = {}) {
  const sessionConfig = config.session && typeof config.session === 'object' ? config.session : {};
  const featureConfig = config.features && typeof config.features === 'object' ? config.features : {};
  const bootstrapConfig = config.bootstrap && typeof config.bootstrap === 'object' ? config.bootstrap : {};
  const ownerValue = envValue(
    config,
    'ownerEmails',
    'OWNER_EMAILS',
    bootstrapConfig.ownerEmail ? [bootstrapConfig.ownerEmail] : [],
  );
  const ownerEmails = (Array.isArray(ownerValue) ? ownerValue : String(ownerValue || '').split(','))
    .map(normalizeEmail)
    .filter(Boolean);
  const couponValue = envValue(config, 'testCoupons', 'TEST_COUPONS', null);
  let testCoupons = couponValue;
  if (typeof couponValue === 'string') {
    try { testCoupons = JSON.parse(couponValue); }
    catch { testCoupons = null; }
  }
  return {
    cookieName: String(envValue(
      config,
      'cookieName',
      'SESSION_COOKIE_NAME',
      sessionConfig.cookieName || 'beta_session',
    )),
    sessionSecret: String(envValue(
      config,
      'sessionSecret',
      'SESSION_SECRET',
      sessionConfig.secret || '',
    )),
    secureCookies: envValue(
      config,
      'secureCookies',
      'SECURE_COOKIES',
      sessionConfig.cookieSecure ?? true,
    ) !== false
      && String(envValue(
        config,
        'secureCookies',
        'SECURE_COOKIES',
        sessionConfig.cookieSecure ?? true,
      )).toLowerCase() !== 'false',
    sessionTtlSeconds: positiveInteger(
      envValue(
        config,
        'sessionTtlSeconds',
        'SESSION_TTL_SECONDS',
        sessionConfig.ttlSeconds || 7 * 24 * 60 * 60,
      ),
      7 * 24 * 60 * 60,
      300,
      90 * 24 * 60 * 60,
    ),
    minimumPasswordLength: positiveInteger(
      envValue(config, 'minimumPasswordLength', 'MINIMUM_PASSWORD_LENGTH', 10),
      10,
      10,
      128,
    ),
    registrationEnabled: enabled(envValue(
      config,
      'registrationEnabled',
      'REGISTRATION_ENABLED',
      featureConfig.registration ?? true,
    )),
    enableDemoLogin: enabled(envValue(
      config,
      'enableDemoLogin',
      'ENABLE_DEMO_LOGIN',
      featureConfig.demoAccess ?? false,
    )),
    demoEmail: normalizeEmail(envValue(config, 'demoEmail', 'DEMO_EMAIL', 'demo@beta.local')),
    demoName: normalizeName(envValue(config, 'demoName', 'DEMO_NAME', 'Conta de demonstração')),
    demoRole: safeRole(envValue(
      config,
      'demoRole',
      'DEMO_ROLE',
      featureConfig.demoRole || 'student',
    ), 'student'),
    demoCourseId: safeIdentifier(envValue(config, 'demoCourseId', 'DEMO_COURSE_ID', 'jornada-lidere')),
    checkoutMode: String(envValue(
      config,
      'checkoutMode',
      'CHECKOUT_MODE',
      featureConfig.paymentsMode || 'disabled',
    )).toLowerCase(),
    ownerEmails: new Set(ownerEmails),
    testCoupons: testCoupons && typeof testCoupons === 'object'
      ? testCoupons
      : {},
    authRateLimitMax: positiveInteger(
      envValue(config, 'authRateLimitMax', 'AUTH_RATE_LIMIT_MAX', 10),
      10,
      1,
      1_000,
    ),
    authRateLimitWindowMs: positiveInteger(
      envValue(config, 'authRateLimitWindowMs', 'AUTH_RATE_LIMIT_WINDOW_MS', 15 * 60 * 1_000),
      15 * 60 * 1_000,
      1_000,
      24 * 60 * 60 * 1_000,
    ),
    scrypt: {
      cost: positiveInteger(envValue(config, 'scryptCost', 'SCRYPT_COST', 16_384), 16_384, 1_024, 1_048_576),
      blockSize: positiveInteger(envValue(config, 'scryptBlockSize', 'SCRYPT_BLOCK_SIZE', 8), 8, 1, 32),
      parallelization: positiveInteger(envValue(config, 'scryptParallelization', 'SCRYPT_PARALLELIZATION', 1), 1, 1, 16),
    },
    allowedOrigins: normalizeAllowedOrigins(envValue(config, 'allowedOrigins', 'ALLOWED_ORIGINS', [])),
  };
}

function normalizeAllowedOrigins(value) {
  const entries = Array.isArray(value) ? value : String(value || '').split(',');
  return new Set(entries.map(item => {
    try { return new URL(String(item).trim()).origin; }
    catch { return ''; }
  }).filter(Boolean));
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase().slice(0, 254);
}

function normalizeName(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').slice(0, 80);
}

function safeRole(value, fallback = 'student') {
  const role = String(value || '').trim().toLowerCase();
  return ['student', 'facilitator', 'admin', 'owner'].includes(role) ? role : fallback;
}

function safeIdentifier(value) {
  const identifier = String(value || '').trim();
  return /^[a-z0-9][a-z0-9_-]{0,95}$/i.test(identifier) ? identifier : '';
}

function nowIso() {
  return new Date().toISOString();
}

function addSeconds(value, seconds) {
  return new Date(value.getTime() + seconds * 1_000).toISOString();
}

function runChanges(result) {
  return Number(result?.meta?.changes ?? result?.changes ?? 0);
}

async function all(statement) {
  const result = await statement.all();
  return Array.isArray(result) ? result : (result?.results || []);
}

async function first(statement) {
  if (typeof statement.first === 'function') return statement.first();
  const rows = await all(statement);
  return rows[0] || null;
}

async function ensureApplicationSchema(DB) {
  if (!DB || typeof DB.prepare !== 'function' || typeof DB.batch !== 'function') {
    throw new ApplicationError(503, 'database_unavailable', 'O banco de dados não está disponível.');
  }
  let initialization = INITIALIZED_DATABASES.get(DB);
  if (!initialization) {
    initialization = DB.batch([
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        member_code TEXT,
        member_code_validated INTEGER NOT NULL DEFAULT 0,
        role TEXT NOT NULL DEFAULT 'student',
        is_demo INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_access_at TEXT
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_sessions (
        token_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        ip_hash TEXT,
        user_agent_hash TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS app_sessions_user_idx ON app_sessions (user_id, expires_at)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_enrollments (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        status TEXT NOT NULL,
        source TEXT NOT NULL,
        checkout_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (user_id, course_id)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS app_enrollments_user_idx ON app_enrollments (user_id, status)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_progress (
        user_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        snapshot_json TEXT NOT NULL,
        version INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (user_id, course_id)
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_quiz_attempts (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        lesson_id TEXT NOT NULL,
        idempotency_key TEXT NOT NULL,
        score INTEGER NOT NULL,
        question_count INTEGER NOT NULL,
        attempts_used INTEGER NOT NULL,
        passed INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        answers_json TEXT NOT NULL,
        results_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (user_id, idempotency_key)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS app_quiz_attempts_user_course_idx ON app_quiz_attempts (user_id, course_id, created_at)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS app_checkouts (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        status TEXT NOT NULL,
        currency TEXT NOT NULL,
        amount_cents INTEGER NOT NULL,
        payment_method TEXT NOT NULL,
        coupon_code TEXT,
        idempotency_key TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (user_id, idempotency_key)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS app_checkouts_user_idx ON app_checkouts (user_id, created_at)'),
    ]).catch(error => {
      INITIALIZED_DATABASES.delete(DB);
      throw error;
    });
    INITIALIZED_DATABASES.set(DB, initialization);
  }
  await initialization;
}

function publicUser(row) {
  return {
    id: row.id,
    name: row.full_name,
    email: row.email,
    memberCode: row.member_code || null,
    memberCodeValidated: Boolean(Number(row.member_code_validated)),
    role: safeRole(row.role),
    isDemo: Boolean(Number(row.is_demo)),
  };
}

function publicFeatures(config) {
  return {
    demoAccess: config.enableDemoLogin,
    registration: config.registrationEnabled,
    paymentsMode: config.checkoutMode,
  };
}

function getRequestIp(request) {
  return String(
    request.headers.get('cf-connecting-ip')
      || request.headers.get('x-forwarded-for')?.split(',')[0]
      || 'unknown',
  ).trim().slice(0, 128);
}

function enforceAuthRateLimit(request, config, action, email = '') {
  const current = Date.now();
  if (AUTH_RATE_BUCKETS.size > 5_000) {
    for (const [key, bucket] of AUTH_RATE_BUCKETS) {
      if (bucket.resetAt <= current) AUTH_RATE_BUCKETS.delete(key);
    }
  }
  const identity = `${getRequestIp(request)}:${normalizeEmail(email)}`;
  const key = `${action}:${hashOpaqueToken(identity)}`;
  const existing = AUTH_RATE_BUCKETS.get(key);
  const bucket = !existing || existing.resetAt <= current
    ? { count: 0, resetAt: current + config.authRateLimitWindowMs }
    : existing;
  bucket.count += 1;
  AUTH_RATE_BUCKETS.set(key, bucket);
  if (bucket.count > config.authRateLimitMax) {
    throw new ApplicationError(
      429,
      'auth_rate_limited',
      'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
      { retryAfterSeconds: Math.max(1, Math.ceil((bucket.resetAt - current) / 1_000)) },
    );
  }
}

function validateUnsafeOrigin(request, config) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method)) return;
  const origin = request.headers.get('origin');
  if (!origin) return;
  const requestOrigin = new URL(request.url).origin;
  if (origin === requestOrigin || config.allowedOrigins.has(origin)) return;
  throw new ApplicationError(403, 'origin_not_allowed', 'A origem da solicitação não é permitida.');
}

async function readJson(request, maximumBytes = 128 * 1_024) {
  const contentType = request.headers.get('content-type') || '';
  if (!contentType.toLowerCase().includes('application/json')) {
    throw new ApplicationError(415, 'json_required', 'Envie os dados como application/json.');
  }
  const declaredLength = Number(request.headers.get('content-length') || 0);
  if (declaredLength > maximumBytes) {
    throw new ApplicationError(413, 'payload_too_large', 'Os dados enviados excedem o limite permitido.');
  }
  const text = await request.text();
  if (Buffer.byteLength(text, 'utf8') > maximumBytes) {
    throw new ApplicationError(413, 'payload_too_large', 'Os dados enviados excedem o limite permitido.');
  }
  try {
    const payload = JSON.parse(text || '{}');
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('object required');
    return payload;
  } catch {
    throw new ApplicationError(400, 'invalid_json', 'O JSON enviado é inválido.');
  }
}

function parseCookie(request, cookieName) {
  const header = request.headers.get('cookie') || '';
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0) continue;
    const name = part.slice(0, separator).trim();
    if (name !== cookieName) continue;
    try { return decodeURIComponent(part.slice(separator + 1).trim()); }
    catch { return ''; }
  }
  return '';
}

function sessionCookie(token, config) {
  const parts = [
    `${config.cookieName}=${encodeURIComponent(token)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${config.sessionTtlSeconds}`,
  ];
  if (config.secureCookies) parts.push('Secure');
  return parts.join('; ');
}

function clearSessionCookie(config) {
  const parts = [
    `${config.cookieName}=`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    'Max-Age=0',
    'Expires=Thu, 01 Jan 1970 00:00:00 GMT',
  ];
  if (config.secureCookies) parts.push('Secure');
  return parts.join('; ');
}

async function createSession(request, context, userId) {
  const token = createOpaqueToken();
  const tokenHash = hashOpaqueToken(token, context.config.sessionSecret);
  const createdAt = nowIso();
  const expiresAt = addSeconds(new Date(), context.config.sessionTtlSeconds);
  await context.DB.prepare(`INSERT INTO app_sessions
    (token_hash, user_id, expires_at, created_at, last_seen_at, ip_hash, user_agent_hash)
    VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .bind(
      tokenHash,
      userId,
      expiresAt,
      createdAt,
      createdAt,
      hashMetadata(getRequestIp(request)),
      hashMetadata(request.headers.get('user-agent')),
    )
    .run();
  return token;
}

async function revokeRequestSession(request, context) {
  const token = parseCookie(request, context.config.cookieName);
  if (!token) return;
  await context.DB.prepare('DELETE FROM app_sessions WHERE token_hash = ?')
    .bind(hashOpaqueToken(token, context.config.sessionSecret))
    .run();
}

export async function resolveSession(request, { DB, config = {} } = {}) {
  const resolvedConfig = applicationConfig(config);
  await ensureApplicationSchema(DB);
  const token = parseCookie(request, resolvedConfig.cookieName);
  if (!token || token.length > 256) return null;
  const tokenHash = hashOpaqueToken(token, resolvedConfig.sessionSecret);
  const row = await first(DB.prepare(`SELECT
      u.id, u.email, u.full_name, u.member_code, u.member_code_validated, u.role, u.is_demo,
      s.expires_at
    FROM app_sessions s
    JOIN app_users u ON u.id = s.user_id
    WHERE s.token_hash = ?`)
    .bind(tokenHash));
  if (!row) return null;
  if (Date.parse(row.expires_at) <= Date.now()) {
    await DB.prepare('DELETE FROM app_sessions WHERE token_hash = ?').bind(tokenHash).run();
    return null;
  }
  const timestamp = nowIso();
  await DB.batch([
    DB.prepare('UPDATE app_sessions SET last_seen_at = ? WHERE token_hash = ?').bind(timestamp, tokenHash),
    DB.prepare('UPDATE app_users SET last_access_at = ?, updated_at = ? WHERE id = ?')
      .bind(timestamp, timestamp, row.id),
  ]);
  return publicUser(row);
}

async function requireSession(request, context) {
  const session = context.session === undefined
    ? await resolveSession(request, context)
    : context.session;
  if (!session) throw new ApplicationError(401, 'authentication_required', 'Entre para continuar.');
  return session;
}

function requireAdmin(user) {
  if (!ADMIN_ROLES.has(user?.role)) {
    throw new ApplicationError(403, 'admin_required', 'Acesso administrativo necessário.');
  }
}

async function findUserByEmail(DB, email) {
  return first(DB.prepare(`SELECT
    id, email, full_name, password_hash, member_code, member_code_validated, role, is_demo
    FROM app_users WHERE email = ?`)
    .bind(normalizeEmail(email)));
}

function validateRegistration(payload, config) {
  const name = normalizeName(payload.name);
  const email = normalizeEmail(payload.email);
  const password = String(payload.password || '');
  const memberCode = String(payload.memberCode || '').trim().slice(0, 40) || null;
  if (name.length < 2) {
    throw new ApplicationError(422, 'invalid_name', 'Informe seu nome completo.');
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new ApplicationError(422, 'invalid_email', 'Informe um e-mail válido.');
  }
  if (password.length < config.minimumPasswordLength || password.length > 256) {
    throw new ApplicationError(
      422,
      'invalid_password',
      `A senha deve ter pelo menos ${config.minimumPasswordLength} caracteres.`,
    );
  }
  return { name, email, password, memberCode };
}

async function handleRegister(request, context) {
  if (!context.config.registrationEnabled) {
    throw new ApplicationError(404, 'registration_disabled', 'Novos cadastros não estão disponíveis.');
  }
  const payload = await readJson(request);
  enforceAuthRateLimit(request, context.config, 'register', payload.email);
  const registration = validateRegistration(payload, context.config);
  const existing = await findUserByEmail(context.DB, registration.email);
  if (existing) {
    throw new ApplicationError(409, 'email_already_registered', 'Este e-mail já está cadastrado.');
  }
  const id = createId('usr');
  const timestamp = nowIso();
  const role = context.config.ownerEmails.has(registration.email) ? 'owner' : 'student';
  const passwordHash = await hashPassword(registration.password, context.config.scrypt);
  try {
    await context.DB.prepare(`INSERT INTO app_users
      (id, email, full_name, password_hash, member_code, member_code_validated, role, is_demo, created_at, updated_at, last_access_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(
        id,
        registration.email,
        registration.name,
        passwordHash,
        registration.memberCode,
        0,
        role,
        0,
        timestamp,
        timestamp,
        timestamp,
      )
      .run();
  } catch (error) {
    if (/unique|duplicate/i.test(String(error?.message || ''))) {
      throw new ApplicationError(409, 'email_already_registered', 'Este e-mail já está cadastrado.');
    }
    throw error;
  }
  const user = await findUserByEmail(context.DB, registration.email);
  const token = await createSession(request, context, id);
  return json(
    {
      success: true,
      user: publicUser(user),
      features: publicFeatures(context.config),
    },
    201,
    { 'Set-Cookie': sessionCookie(token, context.config) },
  );
}

async function handleLogin(request, context) {
  const payload = await readJson(request);
  const email = normalizeEmail(payload.email);
  const password = String(payload.password || '');
  enforceAuthRateLimit(request, context.config, 'login', email);
  const row = email ? await findUserByEmail(context.DB, email) : null;
  const valid = row?.password_hash ? await verifyPassword(password, row.password_hash) : false;
  if (!valid) {
    throw new ApplicationError(401, 'invalid_credentials', 'E-mail ou senha incorretos.');
  }
  const token = await createSession(request, context, row.id);
  return json(
    {
      success: true,
      user: publicUser(row),
      features: publicFeatures(context.config),
    },
    200,
    { 'Set-Cookie': sessionCookie(token, context.config) },
  );
}

async function ensureDemoUser(request, context) {
  if (!context.config.enableDemoLogin) {
    throw new ApplicationError(404, 'demo_disabled', 'A conta de demonstração não está disponível.');
  }
  enforceAuthRateLimit(request, context.config, 'demo', context.config.demoEmail);
  let row = await findUserByEmail(context.DB, context.config.demoEmail);
  if (!row) {
    const id = createId('usr');
    const timestamp = nowIso();
    const unusablePassword = await hashPassword(createOpaqueToken(), context.config.scrypt);
    await context.DB.prepare(`INSERT INTO app_users
      (id, email, full_name, password_hash, member_code, member_code_validated, role, is_demo, created_at, updated_at, last_access_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(
        id,
        context.config.demoEmail,
        context.config.demoName,
        unusablePassword,
        'Beta0000',
        1,
        context.config.demoRole,
        1,
        timestamp,
        timestamp,
        timestamp,
      )
      .run();
    row = await findUserByEmail(context.DB, context.config.demoEmail);
  } else if (!Number(row.is_demo)) {
    throw new ApplicationError(409, 'demo_email_conflict', 'O e-mail de demonstração já pertence a uma conta real.');
  }
  if (context.config.demoCourseId) {
    const course = await getPublishedCourse(context.DB, context.config.demoCourseId, false);
    if (course) await ensureEnrollment(context, row.id, course, 'demo', null);
  }
  const token = await createSession(request, context, row.id);
  return json(
    {
      success: true,
      user: publicUser(row),
      features: publicFeatures(context.config),
    },
    200,
    { 'Set-Cookie': sessionCookie(token, context.config) },
  );
}

function parseCourse(row) {
  if (!row) return null;
  try {
    const data = JSON.parse(row.data_json || '{}');
    return { ...data, id: row.id || data.id, status: row.status || data.status };
  } catch {
    throw new ApplicationError(500, 'invalid_course_data', 'Os dados do curso estão inválidos.');
  }
}

function stripCatalogAnswers(value) {
  if (Array.isArray(value)) return value.map(stripCatalogAnswers);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(
    Object.entries(value)
      .filter(([key]) => !CATALOG_ANSWER_FIELDS.has(key))
      .map(([key, nested]) => [key, stripCatalogAnswers(nested)]),
  );
}

function catalogCourse(row, contentAvailable) {
  const parsed = parseCourse(row);
  const course = stripCatalogAnswers({
    ...parsed,
    id: row.id || parsed.id,
    slug: row.slug || parsed.slug,
    title: row.title || parsed.title,
    status: row.status || parsed.status,
    version: Number(row.version || parsed.version || 1),
    revision: Number(row.version || parsed.revision || parsed.version || 1),
    createdAt: row.created_at || parsed.createdAt,
    updatedAt: row.updated_at || parsed.updatedAt,
    publishedAt: row.published_at || parsed.publishedAt || null,
  });
  course.modules = (Array.isArray(course.modules) ? course.modules : []).map(module => ({
    ...module,
    lessons: (Array.isArray(module.lessons) ? module.lessons : []).map(lesson => {
      if (contentAvailable) return { ...lesson, contentAvailable: true };
      const publicLesson = { ...lesson, quiz: [], contentAvailable: false };
      [
        'captionUrl',
        'pdfMediaId',
        'pdfUrl',
        'videoEmbedId',
        'videoMediaId',
        'videoSource',
        'videoUrl',
      ].forEach(field => delete publicLesson[field]);
      return publicLesson;
    }),
  }));
  return course;
}

async function publishedCourseRows(DB) {
  try {
    return await all(DB.prepare(`SELECT
      id, slug, title, status, data_json, version, created_at, updated_at, published_at
      FROM courses WHERE status = 'published' ORDER BY updated_at DESC`));
  } catch (error) {
    if (!/no such column|does not exist/i.test(String(error?.message || ''))) throw error;
    return all(DB.prepare(`SELECT id, status, data_json
      FROM courses WHERE status = 'published'`));
  }
}

async function handlePublicCatalog(request, context) {
  const user = context.session === undefined
    ? await resolveSession(request, context)
    : context.session;
  const privileged = ADMIN_ROLES.has(user?.role);
  const enrolledCourseIds = new Set();
  if (user && !privileged) {
    const rows = await all(context.DB.prepare(`SELECT course_id
      FROM app_enrollments WHERE user_id = ? AND status = 'active'`)
      .bind(user.id));
    rows.forEach(row => enrolledCourseIds.add(row.course_id));
  }
  const rows = await publishedCourseRows(context.DB);
  const courses = rows.map(row => catalogCourse(
    row,
    privileged || enrolledCourseIds.has(row.id),
  ));
  return json({ courses, initialized: true });
}

async function getPublishedCourse(DB, courseId, required = true) {
  const id = safeIdentifier(courseId);
  if (!id) throw new ApplicationError(404, 'course_not_found', 'Curso não encontrado.');
  let row;
  try {
    row = await first(DB.prepare('SELECT id, status, data_json FROM courses WHERE id = ?').bind(id));
  } catch (error) {
    if (/no such table|does not exist/i.test(String(error?.message || ''))) {
      if (!required) return null;
      throw new ApplicationError(503, 'catalog_unavailable', 'O catálogo ainda não foi configurado.');
    }
    throw error;
  }
  if (!row || row.status !== 'published') {
    if (!required) return null;
    throw new ApplicationError(404, 'course_not_found', 'Curso não encontrado.');
  }
  return parseCourse(row);
}

function orderedLessons(course) {
  return (Array.isArray(course?.modules) ? course.modules : [])
    .slice()
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
    .flatMap(module => (Array.isArray(module.lessons) ? module.lessons : [])
      .slice()
      .sort((a, b) => Number(a.order || 0) - Number(b.order || 0)));
}

function quizRules(course, lesson) {
  const source = { ...(course?.quizConfig || {}), ...(lesson?.quizConfig || {}) };
  const questionCount = Math.max(1, Array.isArray(lesson?.quiz) ? lesson.quiz.length : Number(source.questionsPerLesson || 5));
  return {
    questionCount,
    passingScore: Math.min(
      questionCount,
      Math.max(1, positiveInteger(source.passingScore, Math.min(4, questionCount), 1, questionCount)),
    ),
    maxAttempts: positiveInteger(source.maxAttempts, 3, 1, 10),
  };
}

function initialProgress(course) {
  const lessons = {};
  orderedLessons(course).forEach((lesson, index) => {
    lessons[lesson.id] = {
      lessonId: lesson.id,
      unlocked: index === 0,
      pdfRead: false,
      videoCompleted: false,
      quizStatus: 'locked',
      quizAttemptsUsed: 0,
      quizScore: null,
      lessonCompleted: false,
      attemptRound: 1,
      reReadAfterExhaustion: false,
      reWatchedAfterExhaustion: false,
    };
  });
  return {
    courseId: course.id,
    courseRevision: Number(course.revision || course.version || 1),
    startedAt: nowIso(),
    lessons,
  };
}

function safeInteger(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : fallback;
}

function synchronizeProgress(course, existingValue, incomingValue) {
  const existing = existingValue && typeof existingValue === 'object'
    ? existingValue
    : initialProgress(course);
  const incoming = incomingValue && typeof incomingValue === 'object' ? incomingValue : {};
  const incomingLessons = incoming.lessons && typeof incoming.lessons === 'object' ? incoming.lessons : {};
  const synchronized = initialProgress(course);
  synchronized.startedAt = existing.startedAt || synchronized.startedAt;
  synchronized.reconciledAt = nowIso();
  let previousCompleted = true;
  let transitionCount = 0;

  for (const lesson of orderedLessons(course)) {
    const old = existing.lessons?.[lesson.id] || synchronized.lessons[lesson.id];
    const proposed = incomingLessons[lesson.id] || {};
    const rules = quizRules(course, lesson);
    const state = {
      ...synchronized.lessons[lesson.id],
      unlocked: previousCompleted,
      pdfRead: Boolean(old.pdfRead),
      videoCompleted: Boolean(old.videoCompleted),
      quizStatus: QUIZ_STATUSES.has(old.quizStatus) ? old.quizStatus : 'locked',
      quizAttemptsUsed: Math.max(0, Math.min(rules.maxAttempts, safeInteger(old.quizAttemptsUsed))),
      quizScore: old.quizScore == null ? null : safeInteger(old.quizScore),
      lessonCompleted: Boolean(old.lessonCompleted && old.quizStatus === 'passed'),
      attemptRound: Math.max(1, safeInteger(old.attemptRound, 1)),
      reReadAfterExhaustion: Boolean(old.reReadAfterExhaustion),
      reWatchedAfterExhaustion: Boolean(old.reWatchedAfterExhaustion),
    };

    if (!state.unlocked) {
      synchronized.lessons[lesson.id] = state;
      previousCompleted = false;
      continue;
    }

    if (!state.pdfRead && proposed.pdfRead === true) {
      state.pdfRead = true;
      transitionCount += 1;
    }
    if (!state.videoCompleted && proposed.videoCompleted === true && state.pdfRead) {
      state.videoCompleted = true;
      transitionCount += 1;
    }
    if (state.videoCompleted && state.quizStatus === 'locked') state.quizStatus = 'available';

    if (state.quizStatus === 'exhausted') {
      if (!state.reReadAfterExhaustion && proposed.reReadAfterExhaustion === true) {
        state.reReadAfterExhaustion = true;
        transitionCount += 1;
      }
      if (!state.reWatchedAfterExhaustion && proposed.reWatchedAfterExhaustion === true) {
        state.reWatchedAfterExhaustion = true;
        transitionCount += 1;
      }
      const proposedRound = safeInteger(proposed.attemptRound, state.attemptRound);
      const explicitReset = proposedRound === state.attemptRound + 1
        && proposed.quizStatus === 'available'
        && safeInteger(proposed.quizAttemptsUsed) === 0;
      if (
        (state.reReadAfterExhaustion && state.reWatchedAfterExhaustion)
        || (explicitReset && (state.reReadAfterExhaustion || state.reWatchedAfterExhaustion))
      ) {
        if (explicitReset) transitionCount += 1;
        state.quizStatus = 'available';
        state.quizAttemptsUsed = 0;
        state.quizScore = null;
        state.attemptRound += 1;
        state.reReadAfterExhaustion = false;
        state.reWatchedAfterExhaustion = false;
      }
    }

    const proposedAttempts = safeInteger(proposed.quizAttemptsUsed, state.quizAttemptsUsed);
    if (proposedAttempts > state.quizAttemptsUsed) {
      throw new ApplicationError(
        409,
        'quiz_submission_required',
        'Envie as respostas pela rota segura do teste para registrar a tentativa.',
      );
    }

    if (state.quizStatus !== 'passed') state.lessonCompleted = false;
    synchronized.lessons[lesson.id] = state;
    previousCompleted = state.lessonCompleted;
  }
  if (transitionCount > 1) {
    throw new ApplicationError(
      409,
      'invalid_progress_transition',
      'Envie uma etapa concluída por vez para preservar a ordem do curso.',
    );
  }
  return synchronized;
}

async function ensureEnrollment(context, userId, course, source, checkoutId) {
  const timestamp = nowIso();
  const id = createId('enr');
  await context.DB.prepare(`INSERT INTO app_enrollments
    (id, user_id, course_id, status, source, checkout_id, created_at, updated_at)
    VALUES (?, ?, ?, 'active', ?, ?, ?, ?)
    ON CONFLICT (user_id, course_id) DO UPDATE SET
      status = 'active',
      source = excluded.source,
      checkout_id = COALESCE(excluded.checkout_id, app_enrollments.checkout_id),
      updated_at = excluded.updated_at`)
    .bind(id, userId, course.id, source, checkoutId, timestamp, timestamp)
    .run();
  const enrollment = await first(context.DB.prepare(`SELECT
    id, course_id, status, created_at
    FROM app_enrollments WHERE user_id = ? AND course_id = ?`)
    .bind(userId, course.id));
  const progressRow = await first(context.DB.prepare(
    'SELECT version FROM app_progress WHERE user_id = ? AND course_id = ?',
  ).bind(userId, course.id));
  if (!progressRow) {
    await context.DB.prepare(`INSERT INTO app_progress
      (user_id, course_id, snapshot_json, version, updated_at)
      VALUES (?, ?, ?, 1, ?)
      ON CONFLICT (user_id, course_id) DO NOTHING`)
      .bind(userId, course.id, JSON.stringify(initialProgress(course)), timestamp)
      .run();
  }
  return {
    id: enrollment.id,
    courseId: enrollment.course_id,
    status: enrollment.status,
    enrolledAt: enrollment.created_at,
  };
}

async function handleStudentState(request, context) {
  const user = await requireSession(request, context);
  const enrollmentRows = await all(context.DB.prepare(`SELECT course_id
    FROM app_enrollments
    WHERE user_id = ? AND status = 'active'
    ORDER BY created_at ASC`)
    .bind(user.id));
  const progressRows = await all(context.DB.prepare(`SELECT course_id, snapshot_json
    FROM app_progress WHERE user_id = ?`)
    .bind(user.id));
  const activeIds = new Set(enrollmentRows.map(row => row.course_id));
  const progress = {};
  for (const row of progressRows) {
    if (!activeIds.has(row.course_id)) continue;
    try { progress[row.course_id] = JSON.parse(row.snapshot_json); }
    catch { progress[row.course_id] = null; }
  }
  return json({
    enrollments: [...activeIds],
    progress,
  });
}

async function handleProgressSync(request, context, courseId) {
  const user = await requireSession(request, context);
  const id = safeIdentifier(courseId);
  if (!id) throw new ApplicationError(404, 'course_not_found', 'Curso não encontrado.');
  const enrollment = await first(context.DB.prepare(`SELECT id
    FROM app_enrollments
    WHERE user_id = ? AND course_id = ? AND status = 'active'`)
    .bind(user.id, id));
  if (!enrollment) throw new ApplicationError(403, 'enrollment_required', 'A matrícula ativa é necessária.');
  const course = await getPublishedCourse(context.DB, id);
  const payload = await readJson(request, 512 * 1_024);
  const row = await first(context.DB.prepare(`SELECT snapshot_json, version
    FROM app_progress WHERE user_id = ? AND course_id = ?`)
    .bind(user.id, id));
  let existing;
  try { existing = row ? JSON.parse(row.snapshot_json) : initialProgress(course); }
  catch { existing = initialProgress(course); }
  const progress = synchronizeProgress(course, existing, payload.progress);
  const timestamp = nowIso();
  if (row) {
    const nextVersion = Number(row.version || 1) + 1;
    const result = await context.DB.prepare(`UPDATE app_progress
      SET snapshot_json = ?, version = ?, updated_at = ?
      WHERE user_id = ? AND course_id = ? AND version = ?`)
      .bind(JSON.stringify(progress), nextVersion, timestamp, user.id, id, Number(row.version || 1))
      .run();
    if (runChanges(result) !== 1) {
      throw new ApplicationError(409, 'progress_conflict', 'O progresso mudou em outra sessão. Atualize e tente novamente.');
    }
    return json({ success: true, progress, version: nextVersion });
  }
  await context.DB.prepare(`INSERT INTO app_progress
    (user_id, course_id, snapshot_json, version, updated_at)
    VALUES (?, ?, ?, 1, ?)`)
    .bind(user.id, id, JSON.stringify(progress), timestamp)
    .run();
  return json({ success: true, progress, version: 1 });
}

function lessonQuizQuestions(lesson) {
  const source = Array.isArray(lesson?.quiz)
    ? lesson.quiz
    : Array.isArray(lesson?.quiz?.questions)
      ? lesson.quiz.questions
      : [];
  if (!source.length) {
    throw new ApplicationError(422, 'quiz_not_configured', 'O teste desta lição ainda não foi configurado.');
  }
  return source;
}

function correctOptionFor(question, options) {
  const candidates = [
    question.correctOptionId,
    question.correctOption,
    question.correctAnswer,
    question.answer,
    question.correctIndex,
  ];
  options.forEach((option, index) => {
    if (option?.correct === true || option?.isCorrect === true) candidates.push(index);
  });
  const matches = new Set();
  for (const candidate of candidates) {
    if (candidate === undefined || candidate === null || candidate === '') continue;
    const option = Number.isInteger(candidate)
      ? options[candidate]
      : options.find(item => candidate === item?.id || candidate === item?.text);
    if (option?.id) matches.add(option.id);
  }
  if (matches.size !== 1) {
    throw new ApplicationError(500, 'invalid_quiz_configuration', 'O gabarito deste teste precisa ser revisado.');
  }
  return [...matches][0];
}

function gradeQuizAttempt(lesson, rawAnswers, rules) {
  if (!rawAnswers || typeof rawAnswers !== 'object' || Array.isArray(rawAnswers)) {
    throw new ApplicationError(422, 'invalid_quiz_answers', 'Envie uma alternativa para cada questão.');
  }
  const questions = lessonQuizQuestions(lesson);
  if (questions.length !== rules.questionCount) {
    throw new ApplicationError(500, 'invalid_quiz_configuration', 'A quantidade de questões do teste está inconsistente.');
  }
  const expectedIds = new Set(questions.map(question => safeIdentifier(question?.id)));
  if (expectedIds.has('') || expectedIds.size !== questions.length) {
    throw new ApplicationError(500, 'invalid_quiz_configuration', 'Os identificadores das questões precisam ser revisados.');
  }
  const submittedIds = Object.keys(rawAnswers);
  if (
    submittedIds.length !== questions.length
    || submittedIds.some(questionId => !expectedIds.has(questionId))
  ) {
    throw new ApplicationError(422, 'invalid_quiz_answers', 'Responda todas as questões deste teste uma única vez.');
  }

  let score = 0;
  const graded = [];
  for (const question of questions) {
    const options = Array.isArray(question.options) ? question.options : [];
    const chosenOptionId = safeIdentifier(rawAnswers[question.id]);
    if (!chosenOptionId || !options.some(option => option?.id === chosenOptionId)) {
      throw new ApplicationError(422, 'invalid_quiz_answers', 'Uma das alternativas enviadas não pertence ao teste.');
    }
    const correctOptionId = correctOptionFor(question, options);
    const isCorrect = chosenOptionId === correctOptionId;
    if (isCorrect) score += 1;
    graded.push({
      questionId: question.id,
      chosenOptionId,
      correctOptionId,
      isCorrect,
      explanation: String(question.explanation || '').slice(0, 2_000),
    });
  }
  return { questions, score, graded };
}

function parseJsonObject(value, fallback = {}) {
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

async function findQuizAttempt(DB, userId, idempotencyKey) {
  return first(DB.prepare(`SELECT
    id, course_id, lesson_id, score, question_count, attempts_used, passed, status, results_json
    FROM app_quiz_attempts
    WHERE user_id = ? AND idempotency_key = ?`)
    .bind(userId, idempotencyKey));
}

async function quizProgressRow(DB, userId, courseId) {
  return first(DB.prepare(`SELECT snapshot_json, version
    FROM app_progress WHERE user_id = ? AND course_id = ?`)
    .bind(userId, courseId));
}

function quizAttemptResponse(attempt, progressRow, idempotent = false) {
  const progress = parseJsonObject(progressRow?.snapshot_json, null);
  const results = parseJsonObject(attempt.results_json);
  return json({
    success: true,
    attemptId: attempt.id,
    idempotent,
    score: Number(attempt.score),
    total: Number(attempt.question_count),
    passed: Boolean(Number(attempt.passed)),
    attemptsUsed: Number(attempt.attempts_used),
    status: attempt.status,
    results,
    progress,
    version: Number(progressRow?.version || 1),
  });
}

async function respondToRepeatedQuizAttempt(DB, userId, courseId, lessonId, idempotencyKey) {
  const attempt = await findQuizAttempt(DB, userId, idempotencyKey);
  if (!attempt) return null;
  if (attempt.course_id !== courseId || attempt.lesson_id !== lessonId) {
    throw new ApplicationError(
      409,
      'idempotency_key_reused',
      'Esta chave de envio já foi usada em outro teste.',
    );
  }
  const progressRow = await quizProgressRow(DB, userId, courseId);
  return quizAttemptResponse(attempt, progressRow, true);
}

async function handleQuizAttempt(request, context, courseId, lessonId) {
  const user = await requireSession(request, context);
  const safeCourseId = safeIdentifier(courseId);
  const safeLessonId = safeIdentifier(lessonId);
  if (!safeCourseId || !safeLessonId) {
    throw new ApplicationError(404, 'quiz_not_found', 'Teste não encontrado.');
  }
  const idempotencyKey = String(request.headers.get('idempotency-key') || '').trim();
  if (!/^[a-z0-9][a-z0-9._:-]{7,127}$/i.test(idempotencyKey)) {
    throw new ApplicationError(
      400,
      'idempotency_key_required',
      'O envio do teste precisa de uma chave de segurança válida.',
    );
  }
  const repeated = await respondToRepeatedQuizAttempt(
    context.DB,
    user.id,
    safeCourseId,
    safeLessonId,
    idempotencyKey,
  );
  if (repeated) return repeated;

  const enrollment = await first(context.DB.prepare(`SELECT id
    FROM app_enrollments
    WHERE user_id = ? AND course_id = ? AND status = 'active'`)
    .bind(user.id, safeCourseId));
  if (!enrollment) {
    throw new ApplicationError(403, 'enrollment_required', 'A matrícula ativa é necessária.');
  }
  const course = await getPublishedCourse(context.DB, safeCourseId);
  const lessons = orderedLessons(course);
  const lessonIndex = lessons.findIndex(item => item.id === safeLessonId);
  if (lessonIndex < 0) throw new ApplicationError(404, 'quiz_not_found', 'Teste não encontrado.');
  const lesson = lessons[lessonIndex];
  const rules = quizRules(course, lesson);
  const payload = await readJson(request, 128 * 1_024);
  const grading = gradeQuizAttempt(lesson, payload.answers, rules);
  const run = async (DB) => {
    const inTransactionRepeat = await respondToRepeatedQuizAttempt(
      DB,
      user.id,
      safeCourseId,
      safeLessonId,
      idempotencyKey,
    );
    if (inTransactionRepeat) return inTransactionRepeat;

    const row = await quizProgressRow(DB, user.id, safeCourseId);
    let existing;
    try { existing = row ? JSON.parse(row.snapshot_json) : initialProgress(course); }
    catch { existing = initialProgress(course); }
    const progress = synchronizeProgress(course, existing, existing);
    const lessonProgress = progress.lessons?.[safeLessonId];
    if (
      !lessonProgress?.unlocked
      || !lessonProgress.pdfRead
      || !lessonProgress.videoCompleted
      || !['available', 'failed'].includes(lessonProgress.quizStatus)
      || lessonProgress.quizAttemptsUsed >= rules.maxAttempts
    ) {
      throw new ApplicationError(
        409,
        'quiz_not_available',
        'Conclua as etapas anteriores ou revise o material antes de tentar novamente.',
      );
    }

    lessonProgress.quizAttemptsUsed += 1;
    lessonProgress.quizScore = grading.score;
    const passed = grading.score >= rules.passingScore;
    if (passed) {
      lessonProgress.quizStatus = 'passed';
      lessonProgress.lessonCompleted = true;
      const nextLesson = lessons[lessonIndex + 1];
      if (nextLesson && progress.lessons[nextLesson.id]) progress.lessons[nextLesson.id].unlocked = true;
    } else if (lessonProgress.quizAttemptsUsed >= rules.maxAttempts) {
      lessonProgress.quizStatus = 'exhausted';
      lessonProgress.lessonCompleted = false;
      lessonProgress.reReadAfterExhaustion = false;
      lessonProgress.reWatchedAfterExhaustion = false;
    } else {
      lessonProgress.quizStatus = 'failed';
      lessonProgress.lessonCompleted = false;
    }
    progress.reconciledAt = nowIso();

    const terminal = passed || lessonProgress.quizStatus === 'exhausted';
    const results = Object.fromEntries(grading.graded.map(result => [
      result.questionId,
      {
        chosen: result.chosenOptionId,
        isCorrect: result.isCorrect,
        ...(terminal ? {
          correctOptionId: result.correctOptionId,
          explanation: result.explanation,
        } : {}),
      },
    ]));
    const timestamp = nowIso();
    const nextVersion = Number(row?.version || 0) + 1;
    if (row) {
      const update = await DB.prepare(`UPDATE app_progress
        SET snapshot_json = ?, version = ?, updated_at = ?
        WHERE user_id = ? AND course_id = ? AND version = ?`)
        .bind(
          JSON.stringify(progress),
          nextVersion,
          timestamp,
          user.id,
          safeCourseId,
          Number(row.version),
        )
        .run();
      if (runChanges(update) !== 1) {
        throw new ApplicationError(409, 'progress_conflict', 'O progresso mudou em outra sessão. Atualize e tente novamente.');
      }
    } else {
      const insert = await DB.prepare(`INSERT INTO app_progress
        (user_id, course_id, snapshot_json, version, updated_at)
        VALUES (?, ?, ?, 1, ?)
        ON CONFLICT (user_id, course_id) DO NOTHING`)
        .bind(user.id, safeCourseId, JSON.stringify(progress), timestamp)
        .run();
      if (runChanges(insert) !== 1) {
        throw new ApplicationError(409, 'progress_conflict', 'O progresso mudou em outra sessão. Atualize e tente novamente.');
      }
    }

    const attempt = {
      id: createId('qat'),
      course_id: safeCourseId,
      lesson_id: safeLessonId,
      score: grading.score,
      question_count: grading.questions.length,
      attempts_used: lessonProgress.quizAttemptsUsed,
      passed: passed ? 1 : 0,
      status: lessonProgress.quizStatus,
      results_json: JSON.stringify(results),
    };
    await DB.prepare(`INSERT INTO app_quiz_attempts
      (id, user_id, course_id, lesson_id, idempotency_key, score, question_count, attempts_used,
       passed, status, answers_json, results_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(
        attempt.id,
        user.id,
        safeCourseId,
        safeLessonId,
        idempotencyKey,
        attempt.score,
        attempt.question_count,
        attempt.attempts_used,
        attempt.passed,
        attempt.status,
        JSON.stringify(payload.answers),
        attempt.results_json,
        timestamp,
      )
      .run();
    return quizAttemptResponse(attempt, {
      snapshot_json: JSON.stringify(progress),
      version: nextVersion,
    });
  };

  try {
    return typeof context.DB.transaction === 'function'
      ? await context.DB.transaction(run)
      : await run(context.DB);
  } catch (error) {
    if (/UNIQUE constraint failed|duplicate key/i.test(String(error?.message || error))) {
      const recovered = await respondToRepeatedQuizAttempt(
        context.DB,
        user.id,
        safeCourseId,
        safeLessonId,
        idempotencyKey,
      );
      if (recovered) return recovered;
    }
    throw error;
  }
}

function coursePricing(course) {
  const fullPrice = Number(course?.pricing?.fullPrice || 0);
  if (!Number.isFinite(fullPrice) || fullPrice < 0 || fullPrice > 1_000_000) {
    throw new ApplicationError(422, 'invalid_course_price', 'O preço do curso está inválido.');
  }
  return {
    amountCents: Math.round(fullPrice * 100),
    currency: String(course?.pricing?.currency || 'BRL').toUpperCase() === 'BRL' ? 'BRL' : 'BRL',
    methods: Array.isArray(course?.pricing?.paymentMethods)
      ? course.pricing.paymentMethods.filter(method => PAYMENT_METHODS.has(method))
      : [...PAYMENT_METHODS],
  };
}

function applyTestCoupon(amountCents, couponCode, config) {
  const code = String(couponCode || '').trim().toUpperCase();
  if (!code) return { amountCents, couponCode: null };
  const rule = config.testCoupons[code];
  if (!rule) throw new ApplicationError(422, 'invalid_coupon', 'Código Beta inválido ou indisponível.');
  const percent = Math.max(0, Math.min(100, Number(rule.percent || 0)));
  const fixedCents = Math.max(0, safeInteger(rule.fixedCents));
  const discount = fixedCents || Math.round(amountCents * percent / 100);
  return { amountCents: Math.max(0, amountCents - discount), couponCode: code };
}

async function existingCheckout(context, userId, idempotencyKey) {
  if (!idempotencyKey) return null;
  return first(context.DB.prepare(`SELECT
    id, course_id, status, currency, amount_cents, payment_method
    FROM app_checkouts WHERE user_id = ? AND idempotency_key = ?`)
    .bind(userId, idempotencyKey));
}

function isUniqueConstraintError(error) {
  const code = String(error?.code || '').toUpperCase();
  return error?.name === 'DatabaseConstraintError'
    || code === '23505'
    || code.startsWith('SQLITE_CONSTRAINT')
    || /duplicate key|unique constraint|constraint failed.*unique/i.test(
      String(error?.message || ''),
    );
}

async function checkoutTransaction(context, callback) {
  if (typeof context.DB?.transaction !== 'function') return callback(context);
  return context.DB.transaction(async (transaction) => callback({
    ...context,
    DB: transaction || context.DB,
  }));
}

function assertIdempotentCheckoutMatches(checkout, course, paymentMethod) {
  if (
    checkout.course_id !== course.id
    || checkout.payment_method !== paymentMethod
  ) {
    throw new ApplicationError(
      409,
      'idempotency_conflict',
      'Esta chave de idempotência já foi usada em outra compra.',
    );
  }
}

async function restoreCheckoutResult(context, userId, checkout, course) {
  await ensureEnrollment(context, userId, course, 'checkout_test', checkout.id);
  return checkoutResponse(context, userId, checkout);
}

async function checkoutResponse(context, userId, checkout) {
  const enrollment = await first(context.DB.prepare(`SELECT
    id, course_id, status, created_at
    FROM app_enrollments WHERE user_id = ? AND course_id = ?`)
    .bind(userId, checkout.course_id));
  return json({
    success: checkout.status === 'approved',
    status: checkout.status,
    testMode: true,
    enrollment: enrollment ? {
      id: enrollment.id,
      courseId: enrollment.course_id,
      status: enrollment.status,
      enrolledAt: enrollment.created_at,
    } : null,
    checkout: {
      id: checkout.id,
      amountCents: Number(checkout.amount_cents),
      currency: checkout.currency,
      paymentMethod: checkout.payment_method,
    },
  });
}

async function handleCheckout(request, context) {
  const user = await requireSession(request, context);
  if (context.config.checkoutMode !== 'test') {
    throw new ApplicationError(503, 'checkout_not_configured', 'O checkout ainda não foi configurado.');
  }
  const payload = await readJson(request);
  const course = await getPublishedCourse(context.DB, payload.courseId);
  const method = String(payload.paymentMethod || '').trim();
  const pricing = coursePricing(course);
  if (!PAYMENT_METHODS.has(method) || !pricing.methods.includes(method)) {
    throw new ApplicationError(422, 'invalid_payment_method', 'Forma de pagamento indisponível.');
  }
  const idempotencyKey = String(request.headers.get('idempotency-key') || '').trim().slice(0, 128) || null;
  const repeated = await existingCheckout(context, user.id, idempotencyKey);
  if (repeated) {
    assertIdempotentCheckoutMatches(repeated, course, method);
    return checkoutTransaction(context, transactionContext => (
      restoreCheckoutResult(transactionContext, user.id, repeated, course)
    ));
  }
  const discounted = applyTestCoupon(pricing.amountCents, payload.couponCode, context.config);
  const checkoutId = createId('chk');
  const timestamp = nowIso();
  try {
    return await checkoutTransaction(context, async (transactionContext) => {
      // Recheck inside the transaction to avoid an unnecessary unique-key
      // collision when another request committed between the first read and BEGIN.
      const committed = await existingCheckout(
        transactionContext,
        user.id,
        idempotencyKey,
      );
      if (committed) {
        assertIdempotentCheckoutMatches(committed, course, method);
        return restoreCheckoutResult(
          transactionContext,
          user.id,
          committed,
          course,
        );
      }

      await transactionContext.DB.prepare(`INSERT INTO app_checkouts
        (id, user_id, course_id, status, currency, amount_cents, payment_method, coupon_code, idempotency_key, created_at, updated_at)
        VALUES (?, ?, ?, 'approved', ?, ?, ?, ?, ?, ?, ?)`)
        .bind(
          checkoutId,
          user.id,
          course.id,
          pricing.currency,
          discounted.amountCents,
          method,
          discounted.couponCode,
          idempotencyKey,
          timestamp,
          timestamp,
        )
        .run();
      await ensureEnrollment(
        transactionContext,
        user.id,
        course,
        'checkout_test',
        checkoutId,
      );
      const checkout = await first(transactionContext.DB.prepare(`SELECT
        id, course_id, status, currency, amount_cents, payment_method
        FROM app_checkouts WHERE id = ?`)
        .bind(checkoutId));
      return checkoutResponse(transactionContext, user.id, checkout);
    });
  } catch (error) {
    // Two requests can pass the initial lookup concurrently. The unique key
    // selects the winner; the loser repairs the winner's enrollment/progress
    // before returning the same successful result.
    if (!idempotencyKey || !isUniqueConstraintError(error)) throw error;
    const racedCheckout = await existingCheckout(context, user.id, idempotencyKey);
    if (!racedCheckout) throw error;
    assertIdempotentCheckoutMatches(racedCheckout, course, method);
    return checkoutTransaction(context, transactionContext => (
      restoreCheckoutResult(
        transactionContext,
        user.id,
        racedCheckout,
        course,
      )
    ));
  }
}

function summarizeProgress(snapshot) {
  const lessons = Object.values(snapshot?.lessons || {});
  const completedLessons = lessons.filter(lesson => lesson?.lessonCompleted).length;
  const percentage = lessons.length ? Math.round(completedLessons / lessons.length * 100) : 0;
  const current = lessons.find(lesson => lesson?.unlocked && !lesson?.lessonCompleted);
  return {
    completedLessons,
    currentLesson: current?.lessonId || null,
    percentage,
  };
}

async function handleAdminStudents(request, context) {
  const administrator = await requireSession(request, context);
  requireAdmin(administrator);
  const url = new URL(request.url);
  const search = String(url.searchParams.get('search') || '').trim().toLowerCase().slice(0, 100);
  const courseFilter = safeIdentifier(url.searchParams.get('courseId') || '');
  const limit = positiveInteger(url.searchParams.get('limit'), 500, 1, 500);
  const pattern = `%${search.replace(/[\\%_]/g, '\\$&')}%`;
  const users = await all(context.DB.prepare(`SELECT
    id, email, full_name, member_code, last_access_at
    FROM app_users
    WHERE role = 'student'
      AND (? = '' OR LOWER(full_name) LIKE ? ESCAPE '\\' OR LOWER(email) LIKE ? ESCAPE '\\' OR LOWER(COALESCE(member_code, '')) LIKE ? ESCAPE '\\')
    ORDER BY full_name ASC
    LIMIT ?`)
    .bind(search, pattern, pattern, pattern, limit));
  const userIds = new Set(users.map(user => user.id));
  const rows = userIds.size
    ? await all(context.DB.prepare(`SELECT
        e.user_id, e.course_id, e.created_at, p.snapshot_json
      FROM app_enrollments e
      LEFT JOIN app_progress p ON p.user_id = e.user_id AND p.course_id = e.course_id
      WHERE e.status = 'active'
      ORDER BY e.created_at ASC`))
    : [];
  const byUser = new Map(users.map(user => [user.id, {
    id: user.id,
    name: user.full_name,
    email: user.email,
    memberCode: user.member_code || null,
    enrolledAt: null,
    lastAccess: user.last_access_at || null,
    progress: {},
  }]));
  for (const row of rows) {
    if (!userIds.has(row.user_id)) continue;
    if (courseFilter && row.course_id !== courseFilter) continue;
    const student = byUser.get(row.user_id);
    student.enrolledAt ||= row.created_at;
    try { student.progress[row.course_id] = summarizeProgress(JSON.parse(row.snapshot_json || '{}')); }
    catch { student.progress[row.course_id] = summarizeProgress(null); }
  }
  const students = [...byUser.values()].filter(student => !courseFilter || student.progress[courseFilter]);
  return json({ students });
}

async function dispatchApplicationApi(request, context) {
  const url = new URL(request.url);
  const path = url.pathname;
  if (request.method === 'OPTIONS') return null;
  validateUnsafeOrigin(request, context.config);

  if (path === '/api/courses') {
    if (request.method !== 'GET') return methodNotAllowed(['GET']);
    return handlePublicCatalog(request, context);
  }
  if (path === '/api/auth/register') {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    return handleRegister(request, context);
  }
  if (path === '/api/auth/login') {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    return handleLogin(request, context);
  }
  if (path === '/api/auth/session') {
    if (request.method !== 'GET') return methodNotAllowed(['GET']);
    const user = context.session === undefined
      ? await resolveSession(request, context)
      : context.session;
    if (!user) {
      return json({
        authenticated: false,
        features: publicFeatures(context.config),
      }, 401);
    }
    return json({
      authenticated: true,
      user,
      features: publicFeatures(context.config),
    });
  }
  if (path === '/api/auth/logout') {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    await revokeRequestSession(request, context);
    return empty(204, { 'Set-Cookie': clearSessionCookie(context.config) });
  }
  if (path === '/api/auth/demo') {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    return ensureDemoUser(request, context);
  }
  if (path === '/api/me/state') {
    if (request.method !== 'GET') return methodNotAllowed(['GET']);
    return handleStudentState(request, context);
  }
  const quizMatch = path.match(/^\/api\/me\/quiz\/([a-z0-9][a-z0-9_-]{0,95})\/([a-z0-9][a-z0-9_-]{0,95})\/attempt$/i);
  if (quizMatch) {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    return handleQuizAttempt(request, context, quizMatch[1], quizMatch[2]);
  }
  const progressMatch = path.match(/^\/api\/me\/progress\/([a-z0-9][a-z0-9_-]{0,95})$/i);
  if (progressMatch) {
    if (request.method !== 'PUT') return methodNotAllowed(['PUT']);
    return handleProgressSync(request, context, decodeURIComponent(progressMatch[1]));
  }
  if (path === '/api/checkouts') {
    if (request.method !== 'POST') return methodNotAllowed(['POST']);
    return handleCheckout(request, context);
  }
  if (path === '/api/admin/students') {
    if (request.method !== 'GET') return methodNotAllowed(['GET']);
    return handleAdminStudents(request, context);
  }
  return null;
}

function methodNotAllowed(methods) {
  return json({
    error: {
      code: 'method_not_allowed',
      message: 'Método não permitido.',
    },
  }, 405, { Allow: methods.join(', ') });
}

export async function handleApplicationApi(request, { DB, config = {}, session } = {}) {
  const url = new URL(request.url);
  const knownPrefix = [
    '/api/courses',
    '/api/auth/',
    '/api/me/',
    '/api/checkouts',
    '/api/admin/students',
  ].some(prefix => url.pathname === prefix.replace(/\/$/, '') || url.pathname.startsWith(prefix));
  if (!knownPrefix) return null;
  const context = {
    DB,
    config: applicationConfig(config),
    ...(session === undefined ? {} : { session }),
  };
  try {
    await ensureApplicationSchema(DB);
    return await dispatchApplicationApi(request, context);
  } catch (error) {
    return errorResponse(error);
  }
}
